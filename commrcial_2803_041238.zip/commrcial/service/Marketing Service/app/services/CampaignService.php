<?php

namespace App\Services;

use App\Models\Campaign;
use Illuminate\Support\Facades\Mail;

class CampaignService
{
    public function sendCampaign(Campaign $campaign)
    {
        $recipients = $this->getRecipients($campaign->audience);
        foreach ($recipients as $recipient) {
            Mail::to($recipient->email)->send(new \App\Mail\CampaignMail($campaign, $recipient));
            $campaign->recipients()->create(['customer_id' => $recipient->id, 'sent_at' => now()]);
        }
        $campaign->update(['sent_at' => now()]);
    }

    protected function getRecipients($audience)
    {
        $query = Customer::query();
        if (isset($audience['group']) && $audience['group'] == 'new') {
            $query->where('created_at', '>=', now()->subDays(30));
        }
        // ... شروط أخرى
        return $query->get();
    }
}
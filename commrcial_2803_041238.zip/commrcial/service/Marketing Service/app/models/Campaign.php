<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    protected $fillable = ['name', 'subject', 'content', 'audience', 'sent_at'];
    protected $casts = ['audience' => 'array', 'sent_at' => 'datetime'];

    public function recipients()
    {
        return $this->hasMany(CampaignRecipient::class);
    }
}
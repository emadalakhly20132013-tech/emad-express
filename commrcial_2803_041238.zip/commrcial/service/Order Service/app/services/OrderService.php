<?php

namespace App\Services;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

class OrderService
{
    public function createOrder(array $data)
    {
        return DB::transaction(function () use ($data) {
            $subtotal = 0;
            foreach ($data['items'] as $item) {
                $product = Product::findOrFail($item['product_id']);
                $subtotal += $product->price * $item['quantity'];
            }

            $discount = 0; $couponId = null;
            if (isset($data['coupon_code'])) {
                $result = app(CouponService::class)->applyCoupon($data['coupon_code'], $subtotal);
                if ($result) {
                    $discount = $result['discount'];
                    $couponId = $result['coupon']->id;
                    app(CouponService::class)->incrementUsage($result['coupon']);
                }
            }

            $tax = ($subtotal - $discount) * 0.15;
            $total = $subtotal - $discount + $tax;

            $order = Order::create([
                'order_number' => 'ORD-' . time(),
                'customer_id' => $data['customer_id'],
                'coupon_id' => $couponId,
                'order_date' => now(),
                'status' => 'pending',
                'subtotal' => $subtotal,
                'discount' => $discount,
                'tax' => $tax,
                'total' => $total,
                'payment_method' => $data['payment_method'],
                'payment_status' => 'pending',
                'notes' => $data['notes'] ?? null,
            ]);

            foreach ($data['items'] as $item) {
                $product = Product::findOrFail($item['product_id']);
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'quantity' => $item['quantity'],
                    'price' => $product->price,
                    'total' => $product->price * $item['quantity'],
                    'cost' => $product->cost,
                ]);
            }

            return $order;
        });
    }
}
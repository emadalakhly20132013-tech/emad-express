<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Events\OrderCreated;
use App\Events\OrderPaid;

class Order extends Model
{
    protected $fillable = [
        'order_number', 'customer_id', 'vendor_id', 'coupon_id',
        'order_date', 'status', 'subtotal', 'discount', 'tax',
        'shipping', 'total', 'payment_method', 'payment_status',
        'notes', 'shipping_address', 'billing_address'
    ];

    protected $casts = [
        'order_date' => 'date',
        'subtotal' => 'decimal:2',
        'discount' => 'decimal:2',
        'tax' => 'decimal:2',
        'shipping' => 'decimal:2',
        'total' => 'decimal:2',
    ];

    protected static function booted()
    {
        static::created(fn($order) => event(new OrderCreated($order)));
        static::updated(function ($order) {
            if ($order->isDirty('payment_status') && $order->payment_status == 'paid') {
                event(new OrderPaid($order));
            }
        });
    }

    public function customer() { return $this->belongsTo(Customer::class); }
    public function vendor() { return $this->belongsTo(Vendor::class); }
    public function coupon() { return $this->belongsTo(Coupon::class); }
    public function items() { return $this->hasMany(OrderItem::class); }
    public function payments() { return $this->hasMany(Payment::class); }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $fillable = ['user_id', 'session_id', 'total'];

    protected $casts = ['total' => 'decimal:2'];

    public function user() { return $this->belongsTo(User::class); }
    public function items() { return $this->hasMany(CartItem::class); }

    public function recalculate()
    {
        $this->total = $this->items()->sum('total');
        $this->save();
    }
}
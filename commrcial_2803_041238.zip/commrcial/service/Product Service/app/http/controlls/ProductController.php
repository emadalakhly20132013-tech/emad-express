<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductReview;
use App\Services\ElasticsearchService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;

class ProductController extends Controller
{
    protected $searchService;

    public function __construct(ElasticsearchService $searchService)
    {
        $this->searchService = $searchService;
    }

    public function index(Request $request)
    {
        $filters = $request->only(['category_id', 'vendor_id', 'price_min', 'price_max', 'rating_min']);
        
        $sort = [];
        switch ($request->sort_by) {
            case 'price_asc': $sort = ['price' => 'asc']; break;
            case 'price_desc': $sort = ['price' => 'desc']; break;
            case 'newest': $sort = ['created_at' => 'desc']; break;
            case 'popular': $sort = ['sold_count' => 'desc']; break;
            case 'rating': $sort = ['rating' => 'desc']; break;
            case 'most_viewed': $sort = ['views_count' => 'desc']; break;
        }

        $results = $this->searchService->searchProducts(
            $request->q,
            $filters,
            $sort,
            $request->page ?? 1,
            $request->per_page ?? 20
        );

        return response()->json($results);
    }

    public function show($id)
    {
        $product = Product::with(['category', 'reviews.user'])->findOrFail($id);
        $product->incrementViews();

        $recommendations = $this->getRecommendations($id);

        return response()->json([
            'product' => $product,
            'recommendations' => $recommendations,
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'sku' => 'required|unique:products',
            'price' => 'required|numeric|min:0',
            'cost' => 'required|numeric|min:0',
            'vendor_id' => 'required|exists:vendors,id',
            'category_id' => 'nullable|exists:categories,id',
            'images' => 'nullable|array',
            'attributes' => 'nullable|array',
            'variants' => 'nullable|array',
            'weight' => 'nullable|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $product = Product::create($request->all());
        $this->searchService->indexProduct($product);
        event(new \App\Events\ProductCreated($product));

        return response()->json($product, 201);
    }

    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255',
            'description' => 'sometimes|string',
            'price' => 'sometimes|numeric|min:0',
            'cost' => 'sometimes|numeric|min:0',
            'is_active' => 'sometimes|boolean',
            'is_featured' => 'sometimes|boolean',
            'category_id' => 'nullable|exists:categories,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $product->update($request->all());
        $this->searchService->indexProduct($product);

        return response()->json($product);
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();
        $this->searchService->deleteProduct($id);
        return response()->json(['message' => 'Product deleted']);
    }

    public function addReview(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
            'rating' => 'required|integer|min:1|max:5',
            'review' => 'required|string|min:3',
            'images' => 'nullable|array',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $review = $product->reviews()->create($request->all());
        $product->updateRating();
        $this->searchService->indexProduct($product);

        return response()->json($review, 201);
    }

    public function getReviews($id)
    {
        $product = Product::findOrFail($id);
        $reviews = $product->reviews()->with('user')->latest()->paginate(10);
        return response()->json($reviews);
    }

    public function getRelated($id)
    {
        $product = Product::findOrFail($id);
        
        $related = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('is_active', true)
            ->limit(8)
            ->get();

        return response()->json($related);
    }

    public function getAll(Request $request)
    {
        $products = Product::where('is_active', true)
            ->limit($request->limit ?? 1000)
            ->get();

        return response()->json([
            'data' => $products,
            'total' => $products->count(),
        ]);
    }

    protected function getRecommendations($productId)
    {
        try {
            $response = Http::timeout(3)->get(
                env('RECOMMENDATION_SERVICE_URL', 'http://recommendation-service:8000') . 
                "/recommendations/product/{$productId}?limit=5"
            );
            return $response->json();
        } catch (\Exception $e) {
            return [];
        }
    }
}
<?php

namespace App\Http\Controllers;

use App\Services\ElasticsearchService;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    protected $searchService;

    public function __construct(ElasticsearchService $searchService)
    {
        $this->searchService = $searchService;
    }

    public function search(Request $request)
    {
        $request->validate([
            'q' => 'required|string|min:2',
        ]);

        $filters = $request->only(['category_id', 'vendor_id', 'price_min', 'price_max', 'rating_min']);
        
        $sort = [];
        switch ($request->sort_by) {
            case 'price_asc': $sort = ['price' => 'asc']; break;
            case 'price_desc': $sort = ['price' => 'desc']; break;
            case 'newest': $sort = ['created_at' => 'desc']; break;
            case 'popular': $sort = ['sold_count' => 'desc']; break;
        }

        $results = $this->searchService->searchProducts(
            $request->q,
            $filters,
            $sort,
            $request->page ?? 1,
            $request->per_page ?? 20
        );

        return response()->json($results);
    }

    public function autocomplete(Request $request)
    {
        $request->validate(['q' => 'required|string|min:1']);

        $suggestions = $this->searchService->autocomplete($request->q);

        return response()->json($suggestions);
    }
}
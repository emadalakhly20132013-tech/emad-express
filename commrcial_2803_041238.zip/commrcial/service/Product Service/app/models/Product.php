<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'name', 'description', 'sku', 'vendor_id', 'category_id',
        'price', 'compare_price', 'cost', 'images', 'attributes',
        'variants', 'is_active', 'is_featured', 'rating',
        'review_count', 'sold_count', 'views_count',
        'weight', 'length', 'width', 'height', 'min_order_qty', 'max_order_qty'
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'compare_price' => 'decimal:2',
        'cost' => 'decimal:2',
        'images' => 'array',
        'attributes' => 'array',
        'variants' => 'array',
        'is_active' => 'boolean',
        'is_featured' => 'boolean',
        'rating' => 'float',
    ];

    public function category() { return $this->belongsTo(Category::class); }
    public function reviews() { return $this->hasMany(ProductReview::class); }

    public function incrementViews() { $this->increment('views_count'); }
    public function updateRating() {
        $this->rating = $this->reviews()->avg('rating') ?? 0;
        $this->review_count = $this->reviews()->count();
        $this->save();
    }
}
<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Facades\Cache;

class ProductService
{
    public function getProductWithDetails($id)
    {
        $cacheKey = "product:{$id}";
        
        return Cache::remember($cacheKey, 3600, function () use ($id) {
            return Product::with(['category', 'reviews.user', 'vendor'])
                ->findOrFail($id);
        });
    }

    public function updateStock($productId, $quantity, $type = 'decrease')
    {
        $product = Product::findOrFail($productId);
        
        if ($type == 'decrease') {
            $product->decrement('quantity', $quantity);
            $product->increment('sold_count', $quantity);
        } else {
            $product->increment('quantity', $quantity);
        }
        
        // Clear cache
        Cache::forget("product:{$productId}");
        
        return $product;
    }

    public function getLowStockProducts($threshold = 10)
    {
        return Product::where('quantity', '<=', $threshold)
            ->where('is_active', true)
            ->get();
    }

    public function getTopSellingProducts($limit = 10)
    {
        return Product::orderBy('sold_count', 'desc')
            ->limit($limit)
            ->get();
    }
}
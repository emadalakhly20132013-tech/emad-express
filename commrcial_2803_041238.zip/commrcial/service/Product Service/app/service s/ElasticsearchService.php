<?php

namespace App\Services;

use Elastic\Elasticsearch\ClientBuilder;
use Illuminate\Support\Facades\Log;

class ElasticsearchService
{
    protected $client;
    protected $index = 'products';

    public function __construct()
    {
        $this->client = ClientBuilder::create()
            ->setHosts([env('ELASTICSEARCH_HOST', 'localhost:9200')])
            ->build();
    }

    public function indexProduct($product)
    {
        try {
            $params = [
                'index' => $this->index,
                'id' => $product->id,
                'body' => [
                    'id' => $product->id,
                    'name' => $product->name,
                    'description' => $product->description,
                    'sku' => $product->sku,
                    'vendor_id' => $product->vendor_id,
                    'category_id' => $product->category_id,
                    'price' => (float) $product->price,
                    'is_active' => $product->is_active,
                    'created_at' => $product->created_at->toISOString(),
                ]
            ];
            return $this->client->index($params);
        } catch (\Exception $e) {
            Log::error('Elasticsearch indexing error: ' . $e->getMessage());
            return null;
        }
    }

    public function searchProducts($query, $filters = [], $sort = [], $page = 1, $perPage = 20)
    {
        $must = [];
        if ($query) {
            $must[] = [
                'multi_match' => [
                    'query' => $query,
                    'fields' => ['name^3', 'description', 'sku'],
                    'fuzziness' => 'AUTO',
                ]
            ];
        }

        if (!empty($filters['category_id'])) {
            $must[] = ['term' => ['category_id' => (int) $filters['category_id']]];
        }
        if (!empty($filters['vendor_id'])) {
            $must[] = ['term' => ['vendor_id' => (int) $filters['vendor_id']]];
        }
        if (isset($filters['price_min']) || isset($filters['price_max'])) {
            $range = [];
            if (isset($filters['price_min'])) $range['gte'] = (float) $filters['price_min'];
            if (isset($filters['price_max'])) $range['lte'] = (float) $filters['price_max'];
            $must[] = ['range' => ['price' => $range]];
        }

        $sortQuery = [];
        foreach ($sort as $field => $direction) {
            $sortQuery[] = [$field => ['order' => $direction]];
        }
        if (empty($sortQuery)) $sortQuery[] = ['_score' => ['order' => 'desc']];

        $params = [
            'index' => $this->index,
            'body' => [
                'query' => [
                    'bool' => [
                        'must' => $must ?: ['match_all' => new \stdClass()],
                        'filter' => [['term' => ['is_active' => true]]]
                    ]
                ],
                'sort' => $sortQuery,
                'from' => ($page - 1) * $perPage,
                'size' => $perPage,
            ]
        ];

        try {
            $response = $this->client->search($params);
            $results = [];
            foreach ($response['hits']['hits'] as $hit) {
                $result = $hit['_source'];
                $result['id'] = (int) $hit['_id'];
                $results[] = $result;
            }
            return [
                'data' => $results,
                'total' => $response['hits']['total']['value'],
                'page' => $page,
                'per_page' => $perPage,
            ];
        } catch (\Exception $e) {
            return ['data' => [], 'total' => 0, 'page' => $page, 'per_page' => $perPage];
        }
    }

    public function deleteProduct($id)
    {
        try {
            return $this->client->delete(['index' => $this->index, 'id' => $id]);
        } catch (\Exception $e) { return null; }
    }
}
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SearchController;

Route::get('products/all', [ProductController::class, 'getAll']);

Route::apiResource('products', ProductController::class);
Route::get('products/{product}/reviews', [ProductController::class, 'getReviews']);
Route::post('products/{product}/reviews', [ProductController::class, 'addReview']);
Route::get('products/{product}/related', [ProductController::class, 'getRelated']);

Route::apiResource('categories', CategoryController::class);
Route::get('categories/tree', [CategoryController::class, 'tree']);

Route::get('search', [SearchController::class, 'search']);
Route::get('autocomplete', [SearchController::class, 'autocomplete']);
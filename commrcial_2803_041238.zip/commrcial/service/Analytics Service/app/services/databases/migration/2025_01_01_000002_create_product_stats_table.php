<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('product_stats', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained();
            $table->date('date');
            $table->integer('views')->default(0);
            $table->integer('add_to_cart')->default(0);
            $table->integer('purchases')->default(0);
            $table->decimal('revenue', 12, 2)->default(0);
            $table->timestamps();
            
            $table->unique(['product_id', 'date']);
            $table->index(['date', 'views']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('product_stats');
    }
};
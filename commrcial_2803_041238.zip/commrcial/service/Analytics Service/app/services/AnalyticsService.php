<?php

namespace App\Services;

use App\Models\AnalyticsEvent;
use App\Models\ProductStat;
use Illuminate\Support\Facades\Redis;

class AnalyticsService
{
    protected $cachePrefix = 'analytics:';

    public function trackEvent($eventType, $data)
    {
        $event = AnalyticsEvent::create([
            'event_type' => $eventType,
            'user_id' => auth()->id(),
            'session_id' => session()->getId(),
            'product_id' => $data['product_id'] ?? null,
            'order_id' => $data['order_id'] ?? null,
            'metadata' => $data,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);

        // Update real-time stats
        $this->updateRealTimeStats($eventType, $data);

        return $event;
    }

    public function trackProductView($productId)
    {
        return $this->trackEvent('product_view', ['product_id' => $productId]);
    }

    public function trackAddToCart($productId, $quantity)
    {
        return $this->trackEvent('add_to_cart', [
            'product_id' => $productId,
            'quantity' => $quantity,
        ]);
    }

    public function trackPurchase($orderId, $total, $items)
    {
        return $this->trackEvent('purchase', [
            'order_id' => $orderId,
            'total' => $total,
            'items' => $items,
        ]);
    }

    public function updateRealTimeStats($eventType, $data)
    {
        $date = now()->toDateString();
        
        if ($eventType == 'product_view' && isset($data['product_id'])) {
            Redis::hincrby("stats:product:{$data['product_id']}:{$date}", 'views', 1);
        } elseif ($eventType == 'add_to_cart' && isset($data['product_id'])) {
            Redis::hincrby("stats:product:{$data['product_id']}:{$date}", 'add_to_cart', $data['quantity'] ?? 1);
        } elseif ($eventType == 'purchase' && isset($data['order_id'])) {
            foreach ($data['items'] as $item) {
                Redis::hincrby("stats:product:{$item['product_id']}:{$date}", 'purchases', $item['quantity']);
                Redis::hincrbyfloat("stats:product:{$item['product_id']}:{$date}", 'revenue', $item['total']);
            }
        }
    }

    public function getProductStats($productId, $days = 30)
    {
        $stats = [];
        for ($i = 0; $i < $days; $i++) {
            $date = now()->subDays($i)->toDateString();
            $stats[$date] = [
                'views' => (int) Redis::hget("stats:product:{$productId}:{$date}", 'views') ?? 0,
                'add_to_cart' => (int) Redis::hget("stats:product:{$productId}:{$date}", 'add_to_cart') ?? 0,
                'purchases' => (int) Redis::hget("stats:product:{$productId}:{$date}", 'purchases') ?? 0,
                'revenue' => (float) Redis::hget("stats:product:{$productId}:{$date}", 'revenue') ?? 0,
            ];
        }
        return array_reverse($stats);
    }

    public function getTopProducts($limit = 10, $days = 7)
    {
        $products = [];
        $startDate = now()->subDays($days)->toDateString();
        
        $keys = Redis::keys("stats:product:*:{$startDate}");
        foreach ($keys as $key) {
            preg_match('/product:(\d+):/', $key, $matches);
            $productId = $matches[1] ?? null;
            if ($productId) {
                $views = (int) Redis::hget($key, 'views') ?? 0;
                $products[$productId] = ($products[$productId] ?? 0) + $views;
            }
        }
        
        arsort($products);
        return array_slice($products, 0, $limit, true);
    }

    public function getDashboardStats()
    {
        $today = now()->toDateString();
        $yesterday = now()->subDay()->toDateString();
        
        return [
            'total_views_today' => $this->getTotalViewsForDate($today),
            'total_views_yesterday' => $this->getTotalViewsForDate($yesterday),
            'total_add_to_cart_today' => $this->getTotalAddToCartForDate($today),
            'total_add_to_cart_yesterday' => $this->getTotalAddToCartForDate($yesterday),
            'total_purchases_today' => $this->getTotalPurchasesForDate($today),
            'total_revenue_today' => $this->getTotalRevenueForDate($today),
            'conversion_rate' => $this->getConversionRate($today),
        ];
    }

    protected function getTotalViewsForDate($date)
    {
        $keys = Redis::keys("stats:product:*:{$date}");
        $total = 0;
        foreach ($keys as $key) {
            $total += (int) Redis::hget($key, 'views') ?? 0;
        }
        return $total;
    }

    protected function getTotalAddToCartForDate($date)
    {
        $keys = Redis::keys("stats:product:*:{$date}");
        $total = 0;
        foreach ($keys as $key) {
            $total += (int) Redis::hget($key, 'add_to_cart') ?? 0;
        }
        return $total;
    }

    protected function getTotalPurchasesForDate($date)
    {
        $keys = Redis::keys("stats:product:*:{$date}");
        $total = 0;
        foreach ($keys as $key) {
            $total += (int) Redis::hget($key, 'purchases') ?? 0;
        }
        return $total;
    }

    protected function getTotalRevenueForDate($date)
    {
        $keys = Redis::keys("stats:product:*:{$date}");
        $total = 0;
        foreach ($keys as $key) {
            $total += (float) Redis::hget($key, 'revenue') ?? 0;
        }
        return $total;
    }

    protected function getConversionRate($date)
    {
        $views = $this->getTotalViewsForDate($date);
        $purchases = $this->getTotalPurchasesForDate($date);
        return $views > 0 ? ($purchases / $views) * 100 : 0;
    }
}
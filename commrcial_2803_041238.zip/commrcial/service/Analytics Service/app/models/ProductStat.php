<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductStat extends Model
{
    protected $fillable = [
        'product_id', 'date', 'views', 'add_to_cart', 'purchases', 'revenue'
    ];

    protected $casts = [
        'date' => 'date',
        'views' => 'integer',
        'add_to_cart' => 'integer',
        'purchases' => 'integer',
        'revenue' => 'decimal:2',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function incrementViews()
    {
        $this->increment('views');
    }

    public function incrementAddToCart()
    {
        $this->increment('add_to_cart');
    }

    public function addPurchase($quantity, $amount)
    {
        $this->increment('purchases', $quantity);
        $this->increment('revenue', $amount);
    }
}
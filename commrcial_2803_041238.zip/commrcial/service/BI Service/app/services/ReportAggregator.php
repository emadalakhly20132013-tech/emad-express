<?php

namespace App\Services;

use App\Models\SalesSummary;
use Illuminate\Support\Facades\DB;

class ReportAggregator
{
    public function aggregateDailySales($date)
    {
        $totalSales = DB::table('orders')
            ->whereDate('order_date', $date)
            ->where('payment_status', 'paid')
            ->sum('total');
        $totalOrders = DB::table('orders')
            ->whereDate('order_date', $date)
            ->where('payment_status', 'paid')
            ->count();

        SalesSummary::updateOrCreate(
            ['date' => $date],
            [
                'total_sales' => $totalSales,
                'total_orders' => $totalOrders,
                'average_order_value' => $totalOrders > 0 ? $totalSales / $totalOrders : 0,
            ]
        );
    }
}
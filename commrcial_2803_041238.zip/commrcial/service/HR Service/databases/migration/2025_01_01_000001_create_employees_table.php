<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('employee_number')->unique();
            $table->foreignId('user_id')->nullable()->constrained();
            $table->string('name');
            $table->string('position');
            $table->string('department');
            $table->date('hire_date');
            $table->enum('status', ['active', 'on_leave', 'terminated'])->default('active');
            $table->decimal('base_salary', 10, 2);
            $table->json('allowances')->nullable();
            $table->timestamps();
            $table->index(['department', 'status']);
        });
    }

    public function down() { Schema::dropIfExists('employees'); }
};
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = [
        'employee_number', 'user_id', 'name', 'position', 'department',
        'hire_date', 'status', 'base_salary', 'allowances'
    ];

    protected $casts = [
        'hire_date' => 'date',
        'base_salary' => 'decimal:2',
        'allowances' => 'array',
    ];

    public function user() { return $this->belongsTo(User::class); }
    public function attendances() { return $this->hasMany(Attendance::class); }
    public function leaves() { return $this->hasMany(Leave::class); }
    public function payrolls() { return $this->hasMany(Payroll::class); }

    public function getTotalSalary($month, $year)
    {
        $attendance = $this->attendances()->whereMonth('date', $month)->whereYear('date', $year)->get();
        $workingDays = $attendance->count();
        $overtimeHours = $attendance->sum('overtime_hours');
        $dailyRate = $this->base_salary / 30;
        $overtimeRate = $dailyRate / 8 * 1.5;
        return $this->base_salary + ($overtimeHours * $overtimeRate);
    }
}
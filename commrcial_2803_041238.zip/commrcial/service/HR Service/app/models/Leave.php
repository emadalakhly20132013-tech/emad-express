<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    protected $fillable = ['employee_id', 'type', 'start_date', 'end_date', 'status', 'reason'];

    protected $casts = ['start_date' => 'date', 'end_date' => 'date'];

    public function employee() { return $this->belongsTo(Employee::class); }

    public function getDaysAttribute()
    {
        return $this->start_date->diffInDays($this->end_date) + 1;
    }
}
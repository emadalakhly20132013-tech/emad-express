<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    protected $fillable = ['employee_id', 'date', 'clock_in', 'clock_out', 'overtime_hours'];

    protected $casts = ['date' => 'date', 'clock_in' => 'datetime', 'clock_out' => 'datetime'];

    public function employee() { return $this->belongsTo(Employee::class); }

    public function calculateOvertime()
    {
        if ($this->clock_in && $this->clock_out) {
            $hours = $this->clock_out->diffInHours($this->clock_in);
            $this->overtime_hours = max(0, $hours - 8);
            $this->save();
        }
    }
}
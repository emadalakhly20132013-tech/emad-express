<?php

namespace App\Services;

use Stripe\Stripe;
use Stripe\Charge;
use Stripe\Refund as StripeRefund;
use App\Models\Payment;
use App\Models\Order;

class StripeService
{
    public function __construct()
    {
        Stripe::setApiKey(config('services.stripe.secret'));
    }

    public function charge(Order $order, $token)
    {
        $charge = Charge::create([
            'amount' => $order->total * 100,
            'currency' => 'usd',
            'source' => $token,
            'description' => "Order {$order->order_number}",
            'metadata' => ['order_id' => $order->id],
        ]);

        return Payment::create([
            'order_id' => $order->id,
            'amount' => $order->total,
            'payment_date' => now(),
            'payment_method' => 'card',
            'gateway' => 'stripe',
            'transaction_id' => $charge->id,
            'gateway_status' => 'success',
        ]);
    }

    public function refund(Payment $payment, $amount = null)
    {
        $refund = StripeRefund::create([
            'charge' => $payment->transaction_id,
            'amount' => ($amount ?? $payment->amount) * 100,
        ]);

        return Refund::create([
            'payment_id' => $payment->id,
            'order_id' => $payment->order_id,
            'amount' => $amount ?? $payment->amount,
            'reason' => 'customer_request',
            'status' => 'completed',
            'transaction_id' => $refund->id,
        ]);
    }
}
<?php

namespace App\Services;

use App\Models\Warehouse;
use App\Models\Inventory;
use App\Models\InventoryMovement;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;

class InventoryService
{
    protected $cachePrefix = 'inventory:';

    public function getStock($productId, $warehouseId = null)
    {
        $cacheKey = $this->cachePrefix . "stock:{$productId}:" . ($warehouseId ?? 'all');
        $cached = Redis::get($cacheKey);
        
        if ($cached) {
            return json_decode($cached, true);
        }

        $query = Inventory::where('product_id', $productId);
        if ($warehouseId) {
            $query->where('warehouse_id', $warehouseId);
        }

        $result = $query->get();
        Redis::setex($cacheKey, 3600, json_encode($result));
        return $result;
    }

    public function updateStock($productId, $warehouseId, $quantity, $type, $reference = null)
    {
        return DB::transaction(function () use ($productId, $warehouseId, $quantity, $type, $reference) {
            $inventory = Inventory::where('product_id', $productId)
                ->where('warehouse_id', $warehouseId)
                ->firstOrFail();

            $oldQuantity = $inventory->quantity;

            switch ($type) {
                case 'purchase':
                    $inventory->increment('quantity', $quantity);
                    $inventory->last_restocked = now();
                    break;
                case 'sale':
                    if ($inventory->quantity < $quantity) {
                        throw new \Exception('Insufficient stock');
                    }
                    $inventory->decrement('quantity', $quantity);
                    $inventory->increment('reserved_quantity', $quantity);
                    break;
                case 'return':
                    $inventory->increment('quantity', $quantity);
                    $inventory->decrement('reserved_quantity', $quantity);
                    break;
                case 'adjustment':
                    $inventory->quantity = $quantity;
                    break;
            }

            $inventory->save();

            InventoryMovement::create([
                'product_id' => $productId,
                'warehouse_id' => $warehouseId,
                'type' => $type,
                'quantity' => $quantity,
                'quantity_before' => $oldQuantity,
                'quantity_after' => $inventory->quantity,
                'reference_id' => $reference['id'] ?? null,
                'reference_type' => $reference['type'] ?? null,
                'notes' => $reference['notes'] ?? null,
                'created_by' => auth()->id(),
            ]);

            $this->clearCache($productId);

            if ($inventory->quantity <= $inventory->reorder_point) {
                $this->triggerReorderAlert($productId, $inventory);
            }

            return $inventory;
        });
    }

    public function findNearestWarehouse($latitude, $longitude, $productId = null)
    {
        $warehouses = Warehouse::where('is_active', true)->get();

        if ($productId) {
            $warehouses = $warehouses->filter(function ($warehouse) use ($productId) {
                return $warehouse->isInStock($productId);
            });
        }

        $nearest = null;
        $minDistance = INF;

        foreach ($warehouses as $warehouse) {
            $distance = $warehouse->getDistanceTo($latitude, $longitude);
            if ($distance < $minDistance) {
                $minDistance = $distance;
                $nearest = $warehouse;
            }
        }

        return ['warehouse' => $nearest, 'distance' => $minDistance];
    }

    public function transferStock($productId, $fromWarehouseId, $toWarehouseId, $quantity, $reason = null)
    {
        return DB::transaction(function () use ($productId, $fromWarehouseId, $toWarehouseId, $quantity, $reason) {
            $this->updateStock($productId, $fromWarehouseId, $quantity, 'transfer_out', [
                'type' => 'transfer', 'notes' => "Transfer to warehouse {$toWarehouseId}"
            ]);
            $this->updateStock($productId, $toWarehouseId, $quantity, 'transfer_in', [
                'type' => 'transfer', 'notes' => "Transfer from warehouse {$fromWarehouseId}"
            ]);
            return ['product_id' => $productId, 'from_warehouse' => $fromWarehouseId,
                    'to_warehouse' => $toWarehouseId, 'quantity' => $quantity, 'reason' => $reason];
        });
    }

    public function getLowStockProducts($threshold = null)
    {
        $query = Inventory::whereColumn('quantity', '<=', 'reorder_point')->with('product', 'warehouse');
        if ($threshold) $query->where('quantity', '<=', $threshold);
        return $query->get();
    }

    protected function triggerReorderAlert($productId, $inventory) {}
    protected function clearCache($productId)
    {
        Redis::del($this->cachePrefix . "stock:{$productId}:all");
        foreach (Warehouse::pluck('id') as $warehouseId) {
            Redis::del($this->cachePrefix . "stock:{$productId}:{$warehouseId}");
        }
    }
}
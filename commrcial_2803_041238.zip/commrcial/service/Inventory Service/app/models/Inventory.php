<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
    protected $table = 'inventory';
    
    protected $fillable = [
        'product_id', 'warehouse_id', 'quantity', 'reserved_quantity',
        'min_quantity', 'max_quantity', 'reorder_point', 'last_restocked'
    ];

    protected $casts = [
        'quantity' => 'integer',
        'reserved_quantity' => 'integer',
        'min_quantity' => 'integer',
        'max_quantity' => 'integer',
        'reorder_point' => 'integer',
        'last_restocked' => 'date',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function warehouse()
    {
        return $this->belongsTo(Warehouse::class);
    }

    public function movements()
    {
        return $this->hasMany(InventoryMovement::class);
    }

    public function isLowStock()
    {
        return $this->quantity <= $this->reorder_point;
    }

    public function availableQuantity()
    {
        return $this->quantity - $this->reserved_quantity;
    }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Warehouse extends Model
{
    protected $fillable = ['name', 'code', 'address', 'city', 'country', 'state',
        'zip_code', 'latitude', 'longitude', 'phone', 'email', 'manager_name',
        'is_active', 'is_main', 'capacity'];

    protected $casts = [
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'is_active' => 'boolean',
        'is_main' => 'boolean',
        'capacity' => 'integer',
    ];

    public function inventory() { return $this->hasMany(Inventory::class); }
    public function getDistanceTo($lat, $lng) { /* ... */ }
    public function isInStock($productId, $quantity = 1) { /* ... */ }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Warehouse extends Model
{
    protected $fillable = [
        'name', 'code', 'address', 'city', 'country', 'state',
        'zip_code', 'latitude', 'longitude', 'phone', 'email',
        'manager_name', 'is_active', 'is_main', 'capacity'
    ];

    protected $casts = [
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'is_active' => 'boolean',
        'is_main' => 'boolean',
        'capacity' => 'integer',
    ];

    public function inventory()
    {
        return $this->hasMany(Inventory::class);
    }

    public function getDistanceTo($lat, $lng)
    {
        if (!$this->latitude || !$this->longitude) return INF;
        $earthRadius = 6371;
        $dLat = deg2rad($lat - $this->latitude);
        $dLng = deg2rad($lng - $this->longitude);
        $a = sin($dLat / 2) * sin($dLat / 2) +
             cos(deg2rad($this->latitude)) * cos(deg2rad($lat)) *
             sin($dLng / 2) * sin($dLng / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $earthRadius * $c;
    }

    public function isInStock($productId, $quantity = 1)
    {
        $inventory = $this->inventory()->where('product_id', $productId)->first();
        return $inventory && $inventory->quantity >= $quantity;
    }
}
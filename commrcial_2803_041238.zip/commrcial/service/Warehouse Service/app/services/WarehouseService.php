<?php

namespace App\Services;

use App\Models\Warehouse;
use App\Models\Inventory;
use Illuminate\Support\Facades\Cache;

class WarehouseService
{
    protected $cachePrefix = 'warehouse:';

    public function getNearestWarehouse($latitude, $longitude, $productId = null)
    {
        $cacheKey = $this->cachePrefix . "nearest:{$latitude}:{$longitude}:" . ($productId ?? 'all');
        
        $cached = Cache::get($cacheKey);
        if ($cached) {
            return json_decode($cached, true);
        }

        $warehouses = Warehouse::where('is_active', true)->get();

        if ($productId) {
            $warehouses = $warehouses->filter(function ($warehouse) use ($productId) {
                return $warehouse->isInStock($productId);
            });
        }

        $nearest = null;
        $minDistance = INF;

        foreach ($warehouses as $warehouse) {
            $distance = $warehouse->getDistanceTo($latitude, $longitude);
            if ($distance < $minDistance) {
                $minDistance = $distance;
                $nearest = $warehouse;
            }
        }

        $result = ['warehouse' => $nearest, 'distance' => $minDistance];
        Cache::put($cacheKey, json_encode($result), 3600);
        
        return $result;
    }

    public function getWarehouseStock($warehouseId, $productId = null)
    {
        $query = Inventory::where('warehouse_id', $warehouseId)->with('product');
        if ($productId) {
            $query->where('product_id', $productId);
        }
        return $query->get();
    }

    public function getLowStockWarehouses($threshold = 10)
    {
        return Inventory::where('quantity', '<=', $threshold)
            ->with('warehouse', 'product')
            ->get()
            ->groupBy('warehouse_id');
    }
}
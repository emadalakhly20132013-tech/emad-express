import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import redis
import json
from typing import List, Dict, Tuple
import logging
import os

logger = logging.getLogger(__name__)

class RecommendationEngine:
    def __init__(self):
        self.redis_client = redis.Redis(
            host=os.getenv('REDIS_HOST', 'localhost'),
            port=int(os.getenv('REDIS_PORT', 6379)),
            decode_responses=True
        )
        self.products_df = None
        self.content_similarity = None
        self.tfidf_vectorizer = TfidfVectorizer(stop_words='english', max_features=5000, ngram_range=(1, 2))
        
    def load_products(self, products_data: List[Dict]):
        if not products_data:
            return
        self.products_df = pd.DataFrame(products_data)
        self.products_df['text_features'] = (
            self.products_df.get('name', '').fillna('') + ' ' +
            self.products_df.get('description', '').fillna('') + ' ' +
            self.products_df.get('category_name', '').fillna('')
        )
        tfidf_matrix = self.tfidf_vectorizer.fit_transform(self.products_df['text_features'])
        self.content_similarity = cosine_similarity(tfidf_matrix)
        logger.info(f"Loaded {len(self.products_df)} products")
    
    def get_content_based(self, product_id: int, limit: int = 10) -> Tuple[List[int], List[float]]:
        if self.products_df is None or self.content_similarity is None:
            return [], []
        try:
            idx = self.products_df[self.products_df['id'] == product_id].index[0]
            sim_scores = list(enumerate(self.content_similarity[idx]))
            sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:limit+1]
            product_indices = [i[0] for i in sim_scores]
            scores = [i[1] for i in sim_scores]
            return self.products_df.iloc[product_indices]['id'].tolist(), scores
        except Exception as e:
            logger.error(f"Error: {e}")
            return [], []
    
    def get_popular_products(self, limit: int = 10) -> Tuple[List[int], List[float]]:
        if self.products_df is None:
            return [], []
        if 'sold_count' in self.products_df.columns:
            popular = self.products_df.nlargest(limit, 'sold_count')['id'].tolist()
        else:
            popular = self.products_df.head(limit)['id'].tolist()
        return popular, [1.0] * len(popular)
    
    def get_user_personalized(self, user_id: int, limit: int = 10) -> Tuple[List[int], List[float]]:
        import httpx
        try:
            response = httpx.get(
                f"{os.getenv('ORDER_SERVICE_URL', 'http://order-service:8000')}/api/users/{user_id}/purchased-products",
                timeout=5.0
            )
            purchase_history = response.json() if response.status_code == 200 else []
        except:
            purchase_history = []
        
        if not purchase_history:
            return self.get_popular_products(limit)
        
        recommendations = {}
        for product_id in purchase_history[:10]:
            products, scores = self.get_content_based(product_id, limit // 2)
            for p, s in zip(products, scores):
                recommendations[p] = recommendations.get(p, 0) + s
        
        sorted_items = sorted(recommendations.items(), key=lambda x: x[1], reverse=True)[:limit]
        products = [p for p, _ in sorted_items]
        scores = [s for _, s in sorted_items]
        return products, scores
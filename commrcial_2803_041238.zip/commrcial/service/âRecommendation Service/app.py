from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import logging
import redis
import json
import os
from services.recommendation_engine import RecommendationEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Recommendation Service", version="2.0.0")

engine = RecommendationEngine()
redis_client = redis.Redis(
    host=os.getenv('REDIS_HOST', 'localhost'),
    port=int(os.getenv('REDIS_PORT', 6379)),
    decode_responses=True
)

class RecommendationResponse(BaseModel):
    products: List[int]
    scores: List[float]
    strategy: str
    total: int

@app.on_event("startup")
async def startup_event():
    try:
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.get(
                os.getenv('PRODUCT_SERVICE_URL', 'http://product-service:8000') + '/api/products/all?limit=10000',
                timeout=30.0
            )
            if response.status_code == 200:
                products = response.json()
                if 'data' in products:
                    products = products['data']
                engine.load_products(products)
                logger.info(f"Loaded {len(products)} products")
    except Exception as e:
        logger.error(f"Error loading products: {e}")

@app.get("/recommendations/popular", response_model=RecommendationResponse)
async def get_popular(limit: int = 10):
    products, scores = engine.get_popular_products(limit)
    return RecommendationResponse(products=products, scores=scores, strategy="popular", total=len(products))

@app.get("/recommendations/product/{product_id}", response_model=RecommendationResponse)
async def recommend_by_product(product_id: int, limit: int = 10):
    products, scores = engine.get_content_based(product_id, limit)
    if not products:
        products, scores = engine.get_popular_products(limit)
        strategy = "popular_fallback"
    else:
        strategy = "content_based"
    return RecommendationResponse(products=products, scores=scores, strategy=strategy, total=len(products))

@app.get("/recommendations/user/{user_id}", response_model=RecommendationResponse)
async def recommend_for_user(user_id: int, limit: int = 10):
    products, scores = engine.get_user_personalized(user_id, limit)
    if not products:
        products, scores = engine.get_popular_products(limit)
        strategy = "popular_fallback"
    else:
        strategy = "personalized"
    return RecommendationResponse(products=products, scores=scores, strategy=strategy, total=len(products))

@app.get("/health")
async def health_check():
    return {"status": "healthy", "products_loaded": engine.products_df is not None}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
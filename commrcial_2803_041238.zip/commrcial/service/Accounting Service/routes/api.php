<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AccountingController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\VendorAccountingController;

Route::middleware('auth:api')->group(function () {
    // Financial Reports
    Route::get('balance-sheet', [ReportController::class, 'balanceSheet']);
    Route::get('income-statement', [ReportController::class, 'incomeStatement']);
    Route::get('cash-flow', [ReportController::class, 'cashFlow']);
    Route::get('trial-balance', [ReportController::class, 'trialBalance']);
    
    // Journal Entries
    Route::get('journals', [AccountingController::class, 'journals']);
    Route::post('journals', [AccountingController::class, 'storeJournal']);
    Route::get('journals/{id}', [AccountingController::class, 'showJournal']);
    
    // Vendor Accounting
    Route::get('vendor/{vendorId}/statement', [VendorAccountingController::class, 'statement']);
    Route::get('vendor/{vendorId}/transactions', [VendorAccountingController::class, 'transactions']);
    Route::post('vendor/{vendorId}/payout', [VendorAccountingController::class, 'payout']);
    
    // Product Profitability
    Route::get('product/{productId}/profit', [ReportController::class, 'productProfit']);
    
    // Financial Years
    Route::get('financial-years', [AccountingController::class, 'financialYears']);
    Route::post('financial-years/{year}/close', [AccountingController::class, 'closeYear']);
});
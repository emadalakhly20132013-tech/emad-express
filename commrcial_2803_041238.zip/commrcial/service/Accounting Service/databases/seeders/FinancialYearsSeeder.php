<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\FinancialYear;

class FinancialYearsSeeder extends Seeder
{
    public function run()
    {
        FinancialYear::firstOrCreate(
            ['year' => 2025],
            [
                'start_date' => '2025-01-01',
                'end_date' => '2025-12-31',
                'is_active' => true,
                'is_closed' => false,
            ]
        );
    }
}
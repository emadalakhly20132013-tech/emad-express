<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->string('code', 20)->unique();
            $table->string('name');
            $table->enum('type', ['asset', 'liability', 'equity', 'income', 'expense', 'contra_asset']);
            $table->enum('sub_type', [
                'cash', 'bank', 'receivable', 'inventory', 'fixed_asset',
                'payable', 'tax_payable', 'vendor_payable', 'sales',
                'cost_of_goods_sold', 'commission', 'shipping', 'discount'
            ])->nullable();
            $table->foreignId('parent_id')->nullable()->constrained('accounts');
            $table->decimal('opening_balance', 15, 2)->default(0);
            $table->enum('normal_balance', ['debit', 'credit']);
            $table->foreignId('vendor_id')->nullable()->constrained();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            
            $table->index('code');
            $table->index('type');
        });

        DB::table('accounts')->insert([
            ['code' => '1000', 'name' => 'النقدية', 'type' => 'asset', 'sub_type' => 'cash', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '1010', 'name' => 'البنك', 'type' => 'asset', 'sub_type' => 'bank', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '1100', 'name' => 'العملاء', 'type' => 'asset', 'sub_type' => 'receivable', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '1200', 'name' => 'المخزون', 'type' => 'asset', 'sub_type' => 'inventory', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '1300', 'name' => 'الأصول الثابتة', 'type' => 'asset', 'sub_type' => 'fixed_asset', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '2000', 'name' => 'الموردون', 'type' => 'liability', 'sub_type' => 'payable', 'normal_balance' => 'credit', 'opening_balance' => 0],
            ['code' => '2100', 'name' => 'ضريبة المبيعات المستحقة', 'type' => 'liability', 'sub_type' => 'tax_payable', 'normal_balance' => 'credit', 'opening_balance' => 0],
            ['code' => '2200', 'name' => 'مستحقات البائعين', 'type' => 'liability', 'sub_type' => 'vendor_payable', 'normal_balance' => 'credit', 'opening_balance' => 0],
            ['code' => '3000', 'name' => 'رأس المال', 'type' => 'equity', 'normal_balance' => 'credit', 'opening_balance' => 0],
            ['code' => '3300', 'name' => 'الأرباح المحتجزة', 'type' => 'equity', 'normal_balance' => 'credit', 'opening_balance' => 0],
            ['code' => '4000', 'name' => 'المبيعات', 'type' => 'income', 'sub_type' => 'sales', 'normal_balance' => 'credit', 'opening_balance' => 0],
            ['code' => '4100', 'name' => 'عمولات البائعين', 'type' => 'expense', 'sub_type' => 'commission', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '4200', 'name' => 'مصاريف الشحن', 'type' => 'expense', 'sub_type' => 'shipping', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '4300', 'name' => 'خصومات المبيعات', 'type' => 'contra_asset', 'sub_type' => 'discount', 'normal_balance' => 'debit', 'opening_balance' => 0],
            ['code' => '5000', 'name' => 'تكلفة المبيعات', 'type' => 'expense', 'sub_type' => 'cost_of_goods_sold', 'normal_balance' => 'debit', 'opening_balance' => 0],
        ]);
    }

    public function down()
    {
        Schema::dropIfExists('accounts');
    }
};
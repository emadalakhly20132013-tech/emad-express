<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('account_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('journal_entry_id')->constrained();
            $table->foreignId('account_id')->constrained();
            $table->decimal('debit', 15, 2)->default(0);
            $table->decimal('credit', 15, 2)->default(0);
            $table->text('description')->nullable();
            $table->string('reference_type')->nullable();
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->foreignId('vendor_id')->nullable()->constrained();
            $table->timestamps();
            
            $table->index(['reference_type', 'reference_id']);
            $table->index(['account_id', 'journal_entry_id']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('account_transactions');
    }
};
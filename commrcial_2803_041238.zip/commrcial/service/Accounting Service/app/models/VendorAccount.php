<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorAccount extends Model
{
    protected $fillable = [
        'vendor_id', 'balance', 'pending_balance', 'total_sales',
        'total_commission', 'total_withdrawn'
    ];

    protected $casts = [
        'balance' => 'decimal:2',
        'pending_balance' => 'decimal:2',
        'total_sales' => 'decimal:2',
        'total_commission' => 'decimal:2',
        'total_withdrawn' => 'decimal:2',
    ];

    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }

    public function addBalance($amount, $description)
    {
        $this->balance += $amount;
        $this->save();

        return VendorTransaction::create([
            'vendor_id' => $this->vendor_id,
            'type' => 'sale',
            'amount' => $amount,
            'balance_after' => $this->balance,
            'description' => $description,
        ]);
    }

    public function deductBalance($amount, $description)
    {
        if ($amount > $this->balance) {
            throw new \Exception('Insufficient balance');
        }

        $this->balance -= $amount;
        $this->save();

        return VendorTransaction::create([
            'vendor_id' => $this->vendor_id,
            'type' => 'withdrawal',
            'amount' => -$amount,
            'balance_after' => $this->balance,
            'description' => $description,
        ]);
    }
}
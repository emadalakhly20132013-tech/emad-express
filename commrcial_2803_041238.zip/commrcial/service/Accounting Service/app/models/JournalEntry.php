<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JournalEntry extends Model
{
    protected $fillable = [
        'reference', 'date', 'description', 'financial_year_id',
        'status', 'created_by', 'approved_by', 'approved_at'
    ];

    protected $casts = [
        'date' => 'date',
        'approved_at' => 'datetime',
    ];

    public function transactions()
    {
        return $this->hasMany(AccountTransaction::class);
    }

    public function financialYear()
    {
        return $this->belongsTo(FinancialYear::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }

    public function approvedBy()
    {
        return $this->belongsTo(\App\Models\User::class, 'approved_by');
    }

    public function scopePosted($query)
    {
        return $query->where('status', 'posted');
    }

    public function isBalanced()
    {
        $totalDebit = $this->transactions()->sum('debit');
        $totalCredit = $this->transactions()->sum('credit');
        return $totalDebit == $totalCredit;
    }
}
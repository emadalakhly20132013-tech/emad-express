<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    protected $fillable = [
        'code', 'name', 'type', 'sub_type', 'parent_id',
        'opening_balance', 'normal_balance', 'vendor_id', 'is_active'
    ];

    protected $casts = ['opening_balance' => 'decimal:2', 'is_active' => 'boolean'];

    public function parent() { return $this->belongsTo(Account::class, 'parent_id'); }
    public function children() { return $this->hasMany(Account::class, 'parent_id'); }
    public function transactions() { return $this->hasMany(AccountTransaction::class); }

    public function getBalance($asOfDate = null)
    {
        $query = $this->transactions();
        if ($asOfDate) {
            $query->whereHas('journalEntry', fn($q) => $q->where('date', '<=', $asOfDate));
        }
        $totalDebit = $query->sum('debit');
        $totalCredit = $query->sum('credit');
        return $this->normal_balance == 'debit'
            ? $this->opening_balance + $totalDebit - $totalCredit
            : $this->opening_balance + $totalCredit - $totalDebit;
    }
}
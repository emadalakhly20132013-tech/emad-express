<?php

namespace App\Services;

use App\Models\Account;
use App\Models\JournalEntry;
use App\Models\AccountTransaction;
use App\Models\FinancialYear;
use Illuminate\Support\Facades\DB;

class AccountingService
{
    protected $currentYear;

    public function __construct()
    {
        $this->currentYear = FinancialYear::where('is_active', true)->first();
    }

    public function recordSale($order)
    {
        return DB::transaction(function () use ($order) {
            $journal = $this->createJournalEntry([
                'reference' => "SALE-{$order['order_number']}",
                'date' => $order['order_date'],
                'description' => "مبيعات أمر رقم {$order['order_number']}",
            ]);

            $customerAccount = Account::where('code', '1100')->first();
            $this->addTransaction($journal, $customerAccount, $order['total'], 0);

            $salesAccount = Account::where('code', '4000')->first();
            $this->addTransaction($journal, $salesAccount, 0, $order['subtotal']);

            if ($order['tax'] > 0) {
                $taxAccount = Account::where('code', '2100')->first();
                $this->addTransaction($journal, $taxAccount, 0, $order['tax']);
            }

            return $journal;
        });
    }

    public function getBalanceSheet($asOfDate = null)
    {
        $date = $asOfDate ?? now();
        $assets = Account::asset()->where('is_active', true)
            ->get()->sum(fn($a) => $a->getBalance($date));
        $liabilities = Account::liability()->where('is_active', true)
            ->get()->sum(fn($a) => $a->getBalance($date));
        $equity = Account::equity()->where('is_active', true)
            ->get()->sum(fn($a) => $a->getBalance($date));
        return [
            'assets' => $assets,
            'liabilities' => $liabilities,
            'equity' => $equity,
            'total' => $assets,
            'total_liabilities_equity' => $liabilities + $equity,
            'date' => $date,
        ];
    }

    protected function createJournalEntry($data)
    {
        return JournalEntry::create([
            'reference' => $data['reference'],
            'date' => $data['date'],
            'description' => $data['description'],
            'financial_year_id' => $this->currentYear->id,
            'status' => 'posted',
            'created_by' => auth()->id() ?? 1,
        ]);
    }

    protected function addTransaction($journal, $account, $debit, $credit, $metadata = [])
    {
        return AccountTransaction::create([
            'journal_entry_id' => $journal->id,
            'account_id' => $account->id,
            'debit' => $debit,
            'credit' => $credit,
            'description' => $metadata['description'] ?? null,
        ]);
    }
}
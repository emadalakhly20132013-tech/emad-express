<?php

return [
    'token_lifetimes' => [
        'access_token' => env('PASSPORT_ACCESS_TOKEN_LIFETIME', 3600),
        'refresh_token' => env('PASSPORT_REFRESH_TOKEN_LIFETIME', 1209600),
    ],
];
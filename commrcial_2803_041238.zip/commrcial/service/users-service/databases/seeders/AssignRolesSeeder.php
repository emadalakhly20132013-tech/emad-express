<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class AssignRolesSeeder extends Seeder
{
    public function run()
    {
        $admin = User::where('email', 'admin@example.com')->first();
        if ($admin) $admin->assignRole('admin');

        User::where('email', '!=', 'admin@example.com')->each(function ($user) {
            $user->assignRole('customer');
        });
    }
}
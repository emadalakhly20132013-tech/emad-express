<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            'view products',
            'create orders',
            'edit products',
            'delete products',
            'edit orders',
            'delete orders',
            'manage customers',
            'manage vendors',
            'manage accounting',
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['name' => $perm, 'guard_name' => 'api']);
        }

        $customer = Role::firstOrCreate(['name' => 'customer', 'guard_name' => 'api']);
        $customer->syncPermissions(['view products', 'create orders']);

        $admin = Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'api']);
        $admin->syncPermissions(Permission::all());

        $adminUser = User::firstOrCreate(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Admin',
                'phone' => '123456789',
                'password' => bcrypt('password'),
                'role' => 'admin',
            ]
        );
        $adminUser->assignRole('admin');
    }
}
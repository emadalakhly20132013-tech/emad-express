// مسارات المتجر
Route::get('products', [ProductController::class, 'index']);
Route::get('products/{id}', [ProductController::class, 'show']);

// مسارات العملاء المسجلين (دور customer)
Route::middleware(['auth:api', 'role:customer'])->group(function () {
    Route::post('orders', [OrderController::class, 'store']);
    Route::get('orders', [OrderController::class, 'index']);
});

// مسارات الإدارة (دور admin)
Route::prefix('admin')->middleware(['auth:api', 'role:admin'])->group(function () {
    Route::apiResource('products', ProductController::class)->except(['index', 'show']);
    Route::apiResource('orders', OrderController::class)->except(['index', 'show', 'store']);
    // ... باقي المسارات
});
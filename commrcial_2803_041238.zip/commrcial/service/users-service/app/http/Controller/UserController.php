<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $users = User::with('roles')
            ->when($request->role, fn($q) => $q->where('role', $request->role))
            ->when($request->search, fn($q) => $q->where('name', 'like', "%{$request->search}%")
                ->orWhere('email', 'like', "%{$request->search}%"))
            ->paginate($request->per_page ?? 20);

        return response()->json($users);
    }

    public function show($id)
    {
        $user = User::with(['roles', 'activities' => function($q) {
            $q->latest()->limit(10);
        }])->findOrFail($id);

        return response()->json($user);
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:users,email,' . $id,
            'phone' => 'sometimes|unique:users,phone,' . $id,
            'role' => 'sometimes|in:admin,vendor,customer',
            'is_active' => 'sometimes|boolean',
            'settings' => 'sometimes|array',
        ]);

        $user->update($request->only(['name', 'email', 'phone', 'role', 'is_active', 'settings']));

        if ($request->has('password')) {
            $user->update(['password' => Hash::make($request->password)]);
        }

        $user->recordActivity('updated', ['changes' => $request->all()]);

        return response()->json($user);
    }

    public function updateRole(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $request->validate(['role' => 'required|in:admin,vendor,customer']);
        $user->update(['role' => $request->role]);
        $user->recordActivity('role_updated', ['new_role' => $request->role]);
        return response()->json($user);
    }

    public function activities($id)
    {
        $user = User::findOrFail($id);
        $activities = $user->activities()->latest()->paginate(20);
        return response()->json($activities);
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return response()->json(['message' => 'User deleted']);
    }
}
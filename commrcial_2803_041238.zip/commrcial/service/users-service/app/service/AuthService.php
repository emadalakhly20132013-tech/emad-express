<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cache;

class AuthService
{
    public function attemptLogin($email, $password)
    {
        $user = User::where('email', $email)->first();

        if (!$user || !Hash::check($password, $user->password)) {
            return false;
        }

        return $user;
    }

    public function generateToken($user)
    {
        return $user->createToken('auth_token')->accessToken;
    }

    public function revokeToken($user)
    {
        return $user->token()->revoke();
    }

    public function isTokenValid($token)
    {
        return Cache::get("token:{$token}") !== null;
    }

    public function blacklistToken($token)
    {
        Cache::put("token:{$token}", 'blacklisted', now()->addDays(7));
    }
}
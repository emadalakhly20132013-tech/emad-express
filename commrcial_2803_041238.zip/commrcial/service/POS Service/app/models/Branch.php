<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    protected $fillable = ['name', 'code', 'address', 'phone', 'is_main'];
    protected $casts = ['is_main' => 'boolean'];

    public function posSessions()
    {
        return $this->hasMany(PosSession::class);
    }
}
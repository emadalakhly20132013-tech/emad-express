<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Services\OrderService;
use Illuminate\Http\Request;

class PosOrderController extends Controller
{
    protected $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->orderService = $orderService;
    }

    public function create(Request $request)
    {
        $request->validate([
            'items' => 'required|array',
            'payment_method' => 'required|in:cash,card',
            'branch_id' => 'required|exists:branches,id',
        ]);

        $orderData = [
            'customer_id' => $request->customer_id ?? 1,
            'items' => $request->items,
            'payment_method' => $request->payment_method,
        ];
        $order = $this->orderService->createOrder($orderData);
        $order->update(['branch_id' => $request->branch_id]);

        return response()->json($order, 201);
    }

    public function searchProduct(Request $request)
    {
        $barcode = $request->barcode;
        $product = Product::where('barcode', $barcode)->first();
        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }
        return response()->json([
            'id' => $product->id,
            'name' => $product->name,
            'price' => $product->price,
            'stock' => $product->quantity
        ]);
    }
}
<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\LoyaltyTransaction;
use App\Models\MembershipLevel;

class LoyaltyService
{
    public function addPoints(Customer $customer, $amountSpent)
    {
        $pointsEarned = floor($amountSpent / 10);
        if ($pointsEarned <= 0) return;

        $customer->loyalty_points += $pointsEarned;
        $customer->save();

        LoyaltyTransaction::create([
            'customer_id' => $customer->id,
            'points' => $pointsEarned,
            'type' => 'earn',
            'description' => "شراء بقيمة $amountSpent ريال"
        ]);

        $this->updateMembershipLevel($customer);
    }

    public function redeemPoints(Customer $customer, $pointsToRedeem)
    {
        if ($customer->loyalty_points < $pointsToRedeem) {
            throw new \Exception('نقاط غير كافية');
        }

        $discountValue = $pointsToRedeem * 0.1;

        $customer->loyalty_points -= $pointsToRedeem;
        $customer->save();

        LoyaltyTransaction::create([
            'customer_id' => $customer->id,
            'points' => -$pointsToRedeem,
            'type' => 'redeem',
            'description' => "استبدال نقاط بقيمة $discountValue ريال"
        ]);

        return $discountValue;
    }

    protected function updateMembershipLevel(Customer $customer)
    {
        $level = MembershipLevel::where('min_points', '<=', $customer->loyalty_points)
                    ->orderBy('min_points', 'desc')
                    ->first();
        if ($level && $customer->membership_level_id != $level->id) {
            $customer->membership_level_id = $level->id;
            $customer->save();
        }
    }
}
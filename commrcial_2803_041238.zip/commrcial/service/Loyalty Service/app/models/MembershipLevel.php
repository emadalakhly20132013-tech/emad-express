<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MembershipLevel extends Model
{
    protected $fillable = ['name', 'min_points', 'discount_rate', 'benefits'];
    protected $casts = ['benefits' => 'array'];

    public function customers()
    {
        return $this->hasMany(Customer::class);
    }
}
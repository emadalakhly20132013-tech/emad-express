<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoyaltyTransaction extends Model
{
    protected $fillable = ['customer_id', 'points', 'type', 'description'];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}
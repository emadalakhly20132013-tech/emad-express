<?php

namespace App\Services;

use Illuminate\Support\Facades\Mail;

class EmailService
{
    public function send($to, $subject, $view, $data = [])
    {
        try {
            Mail::send($view, $data, function ($message) use ($to, $subject) {
                $message->to($to)->subject($subject);
            });
            return true;
        } catch (\Exception $e) {
            \Log::error('Email sending failed: ' . $e->getMessage());
            return false;
        }
    }

    public function sendOrderConfirmation($order)
    {
        return $this->send(
            $order->customer->email,
            'تأكيد الطلب #' . $order->order_number,
            'emails.order_confirmation',
            ['order' => $order]
        );
    }

    public function sendOrderShipped($order)
    {
        return $this->send(
            $order->customer->email,
            'تم شحن الطلب #' . $order->order_number,
            'emails.order_shipped',
            ['order' => $order]
        );
    }

    public function sendWelcomeEmail($user)
    {
        return $this->send(
            $user->email,
            'مرحباً بك في منصتنا',
            'emails.welcome',
            ['user' => $user]
        );
    }

    public function sendPasswordReset($user, $token)
    {
        return $this->send(
            $user->email,
            'إعادة تعيين كلمة المرور',
            'emails.password_reset',
            ['user' => $user, 'token' => $token]
        );
    }
}
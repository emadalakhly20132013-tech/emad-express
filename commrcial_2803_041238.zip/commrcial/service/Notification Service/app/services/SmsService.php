<?php

namespace App\Services;

use Twilio\Rest\Client;

class SmsService
{
    protected $client;
    protected $from;

    public function __construct()
    {
        $this->client = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );
        $this->from = config('services.twilio.from');
    }

    public function send($to, $message)
    {
        try {
            $this->client->messages->create($to, [
                'from' => $this->from,
                'body' => $message,
            ]);
            return true;
        } catch (\Exception $e) {
            \Log::error('SMS sending failed: ' . $e->getMessage());
            return false;
        }
    }

    public function sendOrderConfirmation($order)
    {
        $message = "تم استلام طلبك رقم {$order->order_number} بنجاح. شكراً لتسوقك معنا.";
        return $this->send($order->customer->phone, $message);
    }

    public function sendOrderShipped($order)
    {
        $message = "تم شحن طلبك رقم {$order->order_number}. يمكنك تتبع الطلب عبر الرابط: " . route('track.order', $order);
        return $this->send($order->customer->phone, $message);
    }

    public function sendOtp($phone, $code)
    {
        $message = "رمز التحقق الخاص بك هو: {$code}. صالح لمدة 10 دقائق.";
        return $this->send($phone, $message);
    }
}
<?php

namespace App\Http\Controllers;

use App\Models\Vendor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class VendorController extends Controller
{
    public function index(Request $request)
    {
        $vendors = Vendor::where('is_approved', true)->where('is_active', true)
            ->paginate($request->per_page ?? 20);
        return response()->json($vendors);
    }

    public function show($slug)
    {
        $vendor = Vendor::where('slug', $slug)->where('is_approved', true)->firstOrFail();
        return response()->json($vendor);
    }

    public function register(Request $request)
    {
        $user = auth()->user();
        if (Vendor::where('user_id', $user->id)->exists()) {
            return response()->json(['message' => 'Already a vendor'], 400);
        }

        $validator = Validator::make($request->all(), [
            'store_name' => 'required|string|max:255|unique:vendors',
            'description' => 'nullable|string',
            'phone' => 'required|string',
            'address' => 'required|string',
        ]);

        if ($validator->fails()) return response()->json(['errors' => $validator->errors()], 422);

        $vendor = Vendor::create([
            'user_id' => $user->id,
            'store_name' => $request->store_name,
            'slug' => \Str::slug($request->store_name),
            'description' => $request->description,
            'phone' => $request->phone,
            'email' => $user->email,
            'address' => $request->address,
            'commission_rate' => 10,
        ]);

        $vendor->account()->create();
        return response()->json($vendor, 201);
    }

    public function dashboard()
    {
        $vendor = auth()->user()->vendor;
        $stats = [
            'total_products' => $vendor->products()->count(),
            'total_orders' => 0,
            'total_revenue' => $vendor->balance,
            'current_balance' => $vendor->balance,
            'pending_balance' => $vendor->account->pending_balance ?? 0,
            'total_withdrawn' => $vendor->withdrawn,
        ];
        return response()->json($stats);
    }
}
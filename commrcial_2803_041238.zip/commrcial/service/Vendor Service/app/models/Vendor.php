<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor extends Model
{
    protected $fillable = [
        'user_id', 'store_name', 'slug', 'description', 'logo',
        'cover_image', 'phone', 'email', 'address', 'commission_rate',
        'balance', 'withdrawn', 'is_approved', 'is_active', 'settings'
    ];

    protected $casts = [
        'commission_rate' => 'decimal:2',
        'balance' => 'decimal:2',
        'withdrawn' => 'decimal:2',
        'is_approved' => 'boolean',
        'is_active' => 'boolean',
        'settings' => 'array',
    ];

    public function user() { return $this->belongsTo(User::class); }
    public function account() { return $this->hasOne(VendorAccount::class); }
    public function transactions() { return $this->hasMany(VendorTransaction::class); }
    public function products() { return $this->hasMany(Product::class); }

    public function calculateCommission($amount) { return $amount * ($this->commission_rate / 100); }
    public function getEarnings($amount) { return $amount - $this->calculateCommission($amount); }
}
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('vendors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained();
            $table->string('store_name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('logo')->nullable();
            $table->string('cover_image')->nullable();
            $table->string('phone');
            $table->string('email');
            $table->text('address');
            $table->decimal('commission_rate', 5, 2)->default(10.00);
            $table->decimal('balance', 15, 2)->default(0);
            $table->decimal('withdrawn', 15, 2)->default(0);
            $table->boolean('is_approved')->default(false);
            $table->boolean('is_active')->default(true);
            $table->json('settings')->nullable();
            $table->timestamps();
            $table->index(['slug', 'is_approved', 'is_active']);
        });
    }

    public function down() { Schema::dropIfExists('vendors'); }
};
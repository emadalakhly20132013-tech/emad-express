<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('vendor_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_id')->constrained()->onDelete('cascade');
            $table->enum('type', ['sale', 'commission', 'withdrawal', 'adjustment']);
            $table->decimal('amount', 15, 2);
            $table->decimal('balance_after', 15, 2);
            $table->foreignId('order_id')->nullable()->constrained();
            $table->text('description');
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->index(['vendor_id', 'type', 'created_at']);
        });
    }

    public function down() { Schema::dropIfExists('vendor_transactions'); }
};
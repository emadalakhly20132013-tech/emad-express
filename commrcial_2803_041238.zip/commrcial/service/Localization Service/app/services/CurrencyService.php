<?php

namespace App\Services;

use App\Models\Currency;

class CurrencyService
{
    public function convert($amount, $fromCurrency, $toCurrency)
    {
        if ($fromCurrency->code === $toCurrency->code) return $amount;
        $rate = $toCurrency->exchange_rate / $fromCurrency->exchange_rate;
        return round($amount * $rate, 2);
    }

    public function getDefaultCurrency()
    {
        return Currency::where('is_default', true)->first();
    }
}
<template>
  <div class="storefront">
    <div class="hero">
      <div class="hero-content">
        <h1>تسوق أفضل المنتجات</h1>
        <p>اكتشف تشكيلة واسعة من المنتجات بأفضل الأسعار</p>
        <el-button type="primary" size="large" @click="scrollToProducts">تسوق الآن</el-button>
      </div>
    </div>

    <div class="container">
      <div class="featured-products">
        <h2>منتجات مميزة</h2>
        <el-row :gutter="20">
          <el-col :span="6" v-for="product in featured" :key="product.id">
            <el-card class="product-card" :body-style="{ padding: '0px' }">
              <img :src="product.image" class="product-image">
              <div class="product-info">
                <h3>{{ product.name }}</h3>
                <p class="price">{{ product.price }} ريال</p>
                <el-button type="primary" size="small" @click="addToCart(product)">أضف إلى السلة</el-button>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage } from 'element-plus'

export default {
  name: 'StoreHome',
  setup() {
    const featured = ref([])

    const fetchFeatured = async () => {
      try {
        const response = await axios.get('/api/products?featured=true&limit=8')
        featured.value = response.data.data
      } catch (error) {
        console.error('Failed to fetch featured products:', error)
      }
    }

    const addToCart = async (product) => {
      try {
        await axios.post('/api/cart/add', { product_id: product.id, quantity: 1 })
        ElMessage.success('تم إضافة المنتج إلى السلة')
      } catch (error) {
        ElMessage.error('فشل إضافة المنتج إلى السلة')
      }
    }

    const scrollToProducts = () => {
      document.querySelector('.featured-products').scrollIntoView({ behavior: 'smooth' })
    }

    onMounted(() => {
      fetchFeatured()
    })

    return { featured, addToCart, scrollToProducts }
  }
}
</script>

<style scoped>
.hero {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  text-align: center;
  padding: 80px 20px;
  margin-bottom: 40px;
}
.hero h1 {
  font-size: 48px;
  margin-bottom: 20px;
}
.hero p {
  font-size: 18px;
  margin-bottom: 30px;
}
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}
.featured-products h2 {
  text-align: center;
  margin-bottom: 30px;
}
.product-card {
  margin-bottom: 20px;
  transition: transform 0.3s;
}
.product-card:hover {
  transform: translateY(-5px);
}
.product-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
}
.product-info {
  padding: 15px;
  text-align: center;
}
.product-info h3 {
  margin: 0 0 10px;
  font-size: 16px;
}
.product-info .price {
  color: #f56c6c;
  font-size: 18px;
  font-weight: bold;
  margin: 10px 0;
}
</style>
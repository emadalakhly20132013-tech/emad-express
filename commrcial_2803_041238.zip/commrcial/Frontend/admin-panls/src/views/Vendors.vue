<template>
  <div class="vendors">
    <div class="header">
      <h2>البائعون</h2>
      <el-button type="primary" @click="openAddDialog">إضافة بائع</el-button>
    </div>

    <el-card class="filter-card">
      <el-form :inline="true" :model="filters">
        <el-form-item label="البحث">
          <el-input v-model="filters.search" placeholder="اسم المتجر" clearable @clear="fetchVendors" />
        </el-form-item>
        <el-form-item label="الحالة">
          <el-select v-model="filters.status" placeholder="الكل" clearable @change="fetchVendors">
            <el-option label="موافق عليه" value="approved" />
            <el-option label="قيد المراجعة" value="pending" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchVendors">بحث</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-table :data="vendors" style="width: 100%" v-loading="loading">
      <el-table-column prop="store_name" label="اسم المتجر" />
      <el-table-column prop="name" label="صاحب المتجر" />
      <el-table-column prop="email" label="البريد الإلكتروني" />
      <el-table-column prop="phone" label="الهاتف" />
      <el-table-column prop="commission_rate" label="نسبة العمولة">
        <template #default="{ row }">
          {{ row.commission_rate }}%
        </template>
      </el-table-column>
      <el-table-column prop="balance" label="الرصيد">
        <template #default="{ row }">
          {{ formatPrice(row.balance) }}
        </template>
      </el-table-column>
      <el-table-column prop="is_approved" label="الحالة">
        <template #default="{ row }">
          <el-tag :type="row.is_approved ? 'success' : 'warning'">
            {{ row.is_approved ? 'موافق عليه' : 'قيد المراجعة' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="الإجراءات" width="200">
        <template #default="{ row }">
          <el-button v-if="!row.is_approved" type="success" size="small" @click="approveVendor(row)">
            موافقة
          </el-button>
          <el-button type="primary" size="small" @click="viewVendor(row)">عرض</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      v-model:current-page="pagination.page"
      v-model:page-size="pagination.per_page"
      :total="pagination.total"
      layout="total, prev, pager, next"
      @current-change="fetchVendors"
      class="pagination"
    />

    <!-- Add Vendor Dialog -->
    <el-dialog title="إضافة بائع جديد" v-model="dialogVisible" width="500px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="120px">
        <el-form-item label="اسم المتجر" prop="store_name">
          <el-input v-model="form.store_name" />
        </el-form-item>
        <el-form-item label="صاحب المتجر" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="البريد الإلكتروني" prop="email">
          <el-input v-model="form.email" type="email" />
        </el-form-item>
        <el-form-item label="الهاتف" prop="phone">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="العنوان" prop="address">
          <el-input type="textarea" v-model="form.address" rows="2" />
        </el-form-item>
        <el-form-item label="نسبة العمولة" prop="commission_rate">
          <el-input-number v-model="form.commission_rate" :min="0" :max="100" :precision="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">إلغاء</el-button>
        <el-button type="primary" @click="saveVendor" :loading="saving">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Vendors',
  setup() {
    const vendors = ref([])
    const loading = ref(false)
    const saving = ref(false)
    const dialogVisible = ref(false)
    const formRef = ref(null)

    const filters = reactive({
      search: '',
      status: null
    })

    const pagination = reactive({
      page: 1,
      per_page: 20,
      total: 0
    })

    const form = reactive({
      store_name: '',
      name: '',
      email: '',
      phone: '',
      address: '',
      commission_rate: 10
    })

    const rules = {
      store_name: [{ required: true, message: 'اسم المتجر مطلوب', trigger: 'blur' }],
      name: [{ required: true, message: 'اسم صاحب المتجر مطلوب', trigger: 'blur' }],
      email: [
        { required: true, message: 'البريد الإلكتروني مطلوب', trigger: 'blur' },
        { type: 'email', message: 'بريد إلكتروني غير صحيح', trigger: 'blur' }
      ],
      phone: [{ required: true, message: 'رقم الهاتف مطلوب', trigger: 'blur' }],
      address: [{ required: true, message: 'العنوان مطلوب', trigger: 'blur' }]
    }

    const formatPrice = (price) => {
      return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price || 0)
    }

    const fetchVendors = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/admin/vendors', {
          params: {
            page: pagination.page,
            per_page: pagination.per_page,
            search: filters.search,
            status: filters.status
          }
        })
        vendors.value = response.data.data
        pagination.total = response.data.total
      } catch (error) {
        console.error('Failed to fetch vendors:', error)
        ElMessage.error('فشل في تحميل البائعين')
      } finally {
        loading.value = false
      }
    }

    const approveVendor = async (vendor) => {
      ElMessageBox.confirm(`هل أنت متأكد من الموافقة على بائع "${vendor.store_name}"؟`, 'تأكيد الموافقة', {
        confirmButtonText: 'موافقة',
        cancelButtonText: 'إلغاء',
        type: 'info'
      }).then(async () => {
        try {
          await axios.post(`/api/admin/vendors/${vendor.id}/approve`)
          ElMessage.success('تمت الموافقة على البائع')
          fetchVendors()
        } catch (error) {
          console.error('Failed to approve vendor:', error)
          ElMessage.error('فشل في الموافقة على البائع')
        }
      })
    }

    const viewVendor = async (vendor) => {
      // يمكن إضافة تفاصيل البائع هنا
      ElMessage.info(`عرض تفاصيل البائع: ${vendor.store_name}`)
    }

    const openAddDialog = () => {
      resetForm()
      dialogVisible.value = true
    }

    const saveVendor = async () => {
      const valid = await formRef.value?.validate()
      if (!valid) return

      saving.value = true
      try {
        await axios.post('/api/admin/vendors', form)
        ElMessage.success('تم إضافة البائع بنجاح')
        dialogVisible.value = false
        fetchVendors()
      } catch (error) {
        console.error('Failed to save vendor:', error)
        ElMessage.error('فشل في إضافة البائع')
      } finally {
        saving.value = false
      }
    }

    const resetForm = () => {
      Object.assign(form, {
        store_name: '',
        name: '',
        email: '',
        phone: '',
        address: '',
        commission_rate: 10
      })
    }

    onMounted(() => {
      fetchVendors()
    })

    return {
      vendors,
      loading,
      saving,
      dialogVisible,
      filters,
      pagination,
      form,
      rules,
      formRef,
      formatPrice,
      fetchVendors,
      approveVendor,
      viewVendor,
      openAddDialog,
      saveVendor
    }
  }
}
</script>

<style scoped>
.vendors {
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}
.filter-card {
  margin-bottom: 20px;
}
.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>
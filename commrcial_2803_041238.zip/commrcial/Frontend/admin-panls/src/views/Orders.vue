<template>
  <div class="orders">
    <div class="header">
      <h2>الطلبات</h2>
    </div>

    <el-card class="filter-card">
      <el-form :inline="true" :model="filters">
        <el-form-item label="رقم الطلب">
          <el-input v-model="filters.order_number" placeholder="رقم الطلب" clearable @clear="fetchOrders" />
        </el-form-item>
        <el-form-item label="العميل">
          <el-input v-model="filters.customer" placeholder="اسم العميل" clearable @clear="fetchOrders" />
        </el-form-item>
        <el-form-item label="الحالة">
          <el-select v-model="filters.status" placeholder="الكل" clearable @change="fetchOrders">
            <el-option label="قيد الانتظار" value="pending" />
            <el-option label="قيد المعالجة" value="processing" />
            <el-option label="تم الشحن" value="shipped" />
            <el-option label="تم التسليم" value="delivered" />
            <el-option label="ملغي" value="cancelled" />
          </el-select>
        </el-form-item>
        <el-form-item label="التاريخ">
          <el-date-picker v-model="filters.date_range" type="daterange" range-separator="إلى" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchOrders">بحث</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-table :data="orders" style="width: 100%" v-loading="loading">
      <el-table-column prop="order_number" label="رقم الطلب" />
      <el-table-column prop="customer_name" label="العميل" />
      <el-table-column prop="total" label="الإجمالي">
        <template #default="{ row }">
          {{ formatPrice(row.total) }}
        </template>
      </el-table-column>
      <el-table-column prop="order_date" label="التاريخ">
        <template #default="{ row }">
          {{ formatDate(row.order_date) }}
        </template>
      </el-table-column>
      <el-table-column prop="status" label="الحالة">
        <template #default="{ row }">
          <el-select v-model="row.status" size="small" @change="updateStatus(row)" :disabled="updating">
            <el-option label="قيد الانتظار" value="pending" />
            <el-option label="قيد المعالجة" value="processing" />
            <el-option label="تم الشحن" value="shipped" />
            <el-option label="تم التسليم" value="delivered" />
            <el-option label="ملغي" value="cancelled" />
          </el-select>
        </template>
      </el-table-column>
      <el-table-column label="الإجراءات">
        <template #default="{ row }">
          <el-button type="primary" size="small" @click="viewOrder(row)">عرض التفاصيل</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      v-model:current-page="pagination.page"
      v-model:page-size="pagination.per_page"
      :total="pagination.total"
      layout="total, prev, pager, next"
      @current-change="fetchOrders"
      class="pagination"
    />

    <!-- Order Details Dialog -->
    <el-dialog :title="`تفاصيل الطلب #${selectedOrder?.order_number}`" v-model="dialogVisible" width="800px">
      <div v-if="selectedOrder">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="رقم الطلب">{{ selectedOrder.order_number }}</el-descriptions-item>
          <el-descriptions-item label="التاريخ">{{ formatDate(selectedOrder.order_date) }}</el-descriptions-item>
          <el-descriptions-item label="العميل">{{ selectedOrder.customer_name }}</el-descriptions-item>
          <el-descriptions-item label="البريد الإلكتروني">{{ selectedOrder.customer_email }}</el-descriptions-item>
          <el-descriptions-item label="الهاتف">{{ selectedOrder.customer_phone }}</el-descriptions-item>
          <el-descriptions-item label="العنوان">{{ selectedOrder.shipping_address }}</el-descriptions-item>
          <el-descriptions-item label="طريقة الدفع">{{ selectedOrder.payment_method }}</el-descriptions-item>
          <el-descriptions-item label="حالة الدفع">
            <el-tag :type="selectedOrder.payment_status === 'paid' ? 'success' : 'warning'">
              {{ selectedOrder.payment_status === 'paid' ? 'مدفوع' : 'قيد الانتظار' }}
            </el-tag>
          </el-descriptions-item>
        </el-descriptions>

        <el-divider>المنتجات</el-divider>
        <el-table :data="selectedOrder.items" style="width: 100%">
          <el-table-column prop="product_name" label="المنتج" />
          <el-table-column prop="quantity" label="الكمية" width="100" />
          <el-table-column prop="price" label="السعر">
            <template #default="{ row }">
              {{ formatPrice(row.price) }}
            </template>
          </el-table-column>
          <el-table-column prop="total" label="الإجمالي">
            <template #default="{ row }">
              {{ formatPrice(row.total) }}
            </template>
          </el-table-column>
        </el-table>

        <el-divider>ملخص الطلب</el-divider>
        <div class="summary">
          <div>المجموع الفرعي: {{ formatPrice(selectedOrder.subtotal) }}</div>
          <div>الخصم: -{{ formatPrice(selectedOrder.discount) }}</div>
          <div>الضريبة: {{ formatPrice(selectedOrder.tax) }}</div>
          <div>الشحن: {{ formatPrice(selectedOrder.shipping) }}</div>
          <div class="total">الإجمالي: {{ formatPrice(selectedOrder.total) }}</div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage } from 'element-plus'

export default {
  name: 'Orders',
  setup() {
    const orders = ref([])
    const loading = ref(false)
    const updating = ref(false)
    const dialogVisible = ref(false)
    const selectedOrder = ref(null)

    const filters = reactive({
      order_number: '',
      customer: '',
      status: null,
      date_range: null
    })

    const pagination = reactive({
      page: 1,
      per_page: 20,
      total: 0
    })

    const formatPrice = (price) => {
      return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price || 0)
    }

    const formatDate = (date) => {
      return new Date(date).toLocaleDateString('ar-SA')
    }

    const fetchOrders = async () => {
      loading.value = true
      try {
        const params = {
          page: pagination.page,
          per_page: pagination.per_page,
          order_number: filters.order_number,
          customer: filters.customer,
          status: filters.status
        }
        if (filters.date_range) {
          params.start_date = filters.date_range[0]
          params.end_date = filters.date_range[1]
        }
        const response = await axios.get('/api/admin/orders', { params })
        orders.value = response.data.data
        pagination.total = response.data.total
      } catch (error) {
        console.error('Failed to fetch orders:', error)
        ElMessage.error('فشل في تحميل الطلبات')
      } finally {
        loading.value = false
      }
    }

    const updateStatus = async (order) => {
      updating.value = true
      try {
        await axios.put(`/api/admin/orders/${order.id}/status`, { status: order.status })
        ElMessage.success('تم تحديث حالة الطلب')
        fetchOrders()
      } catch (error) {
        console.error('Failed to update order status:', error)
        ElMessage.error('فشل في تحديث حالة الطلب')
        fetchOrders()
      } finally {
        updating.value = false
      }
    }

    const viewOrder = async (order) => {
      try {
        const response = await axios.get(`/api/admin/orders/${order.id}`)
        selectedOrder.value = response.data
        dialogVisible.value = true
      } catch (error) {
        console.error('Failed to fetch order details:', error)
        ElMessage.error('فشل في تحميل تفاصيل الطلب')
      }
    }

    onMounted(() => {
      fetchOrders()
    })

    return {
      orders,
      loading,
      updating,
      dialogVisible,
      selectedOrder,
      filters,
      pagination,
      formatPrice,
      formatDate,
      fetchOrders,
      updateStatus,
      viewOrder
    }
  }
}
</script>

<style scoped>
.orders {
  padding: 20px;
}
.header {
  margin-bottom: 20px;
}
.filter-card {
  margin-bottom: 20px;
}
.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
.summary {
  text-align: right;
  max-width: 300px;
  margin-right: auto;
}
.summary div {
  margin: 10px 0;
}
.summary .total {
  font-size: 18px;
  font-weight: bold;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
</style>
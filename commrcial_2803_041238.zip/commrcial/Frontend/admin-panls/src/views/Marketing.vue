<template>
  <div>
    <h2>إدارة الحملات</h2>
    <el-button type="primary" @click="openCampaignDialog">حملة جديدة</el-button>
    <el-table :data="campaigns">
      <el-table-column prop="name" label="الاسم" />
      <el-table-column prop="subject" label="الموضوع" />
      <el-table-column prop="sent_at" label="تاريخ الإرسال" />
      <el-table-column label="الإجراءات">
        <template #default="{ row }">
          <el-button size="small" @click="sendCampaign(row)" :disabled="row.sent_at">إرسال</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- باقي الكود كما في الرد السابق -->
  </div>
</template>
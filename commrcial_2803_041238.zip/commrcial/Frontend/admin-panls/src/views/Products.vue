<template>
  <div class="products">
    <div class="header">
      <h2>المنتجات</h2>
      <el-button type="primary" @click="openAddDialog">إضافة منتج جديد</el-button>
    </div>

    <el-card class="filter-card">
      <el-form :inline="true" :model="filters">
        <el-form-item label="البحث">
          <el-input v-model="filters.search" placeholder="اسم المنتج أو SKU" clearable @clear="fetchProducts" />
        </el-form-item>
        <el-form-item label="الفئة">
          <el-select v-model="filters.category_id" placeholder="الكل" clearable @change="fetchProducts">
            <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="الحالة">
          <el-select v-model="filters.status" placeholder="الكل" clearable @change="fetchProducts">
            <el-option label="نشط" value="active" />
            <el-option label="غير نشط" value="inactive" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchProducts">بحث</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-table :data="products" style="width: 100%" v-loading="loading">
      <el-table-column prop="id" label="#" width="60" />
      <el-table-column label="الصورة" width="80">
        <template #default="{ row }">
          <img :src="row.image || '/images/default.png'" class="product-image" />
        </template>
      </el-table-column>
      <el-table-column prop="name" label="الاسم" />
      <el-table-column prop="sku" label="SKU" />
      <el-table-column prop="price" label="السعر">
        <template #default="{ row }">
          {{ formatPrice(row.price) }}
        </template>
      </el-table-column>
      <el-table-column prop="quantity" label="الكمية">
        <template #default="{ row }">
          <span :class="{ 'low-stock': row.quantity <= row.min_quantity }">
            {{ row.quantity }}
          </span>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="الحالة">
        <template #default="{ row }">
          <el-tag :type="row.is_active ? 'success' : 'danger'">
            {{ row.is_active ? 'نشط' : 'غير نشط' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="الإجراءات" width="150">
        <template #default="{ row }">
          <el-button type="warning" size="small" @click="editProduct(row)">تعديل</el-button>
          <el-button type="danger" size="small" @click="deleteProduct(row)">حذف</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      v-model:current-page="pagination.page"
      v-model:page-size="pagination.per_page"
      :total="pagination.total"
      layout="total, prev, pager, next"
      @current-change="fetchProducts"
      class="pagination"
    />

    <!-- Add/Edit Dialog -->
    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="600px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="120px">
        <el-form-item label="الاسم" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="SKU" prop="sku">
          <el-input v-model="form.sku" />
        </el-form-item>
        <el-form-item label="السعر" prop="price">
          <el-input-number v-model="form.price" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="التكلفة" prop="cost">
          <el-input-number v-model="form.cost" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="الكمية" prop="quantity">
          <el-input-number v-model="form.quantity" :min="0" />
        </el-form-item>
        <el-form-item label="الحد الأدنى" prop="min_quantity">
          <el-input-number v-model="form.min_quantity" :min="0" />
        </el-form-item>
        <el-form-item label="الفئة">
          <el-select v-model="form.category_id" placeholder="اختر الفئة">
            <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="الوصف">
          <el-input type="textarea" v-model="form.description" rows="3" />
        </el-form-item>
        <el-form-item label="الصورة">
          <input type="file" @change="handleImageUpload" accept="image/*" />
          <div v-if="form.imagePreview" class="image-preview">
            <img :src="form.imagePreview" width="100" />
          </div>
        </el-form-item>
        <el-form-item label="نشط">
          <el-switch v-model="form.is_active" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">إلغاء</el-button>
        <el-button type="primary" @click="saveProduct" :loading="saving">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Products',
  setup() {
    const products = ref([])
    const categories = ref([])
    const loading = ref(false)
    const saving = ref(false)
    const dialogVisible = ref(false)
    const dialogTitle = ref('إضافة منتج')
    const editingId = ref(null)
    const formRef = ref(null)

    const filters = reactive({
      search: '',
      category_id: null,
      status: null
    })

    const pagination = reactive({
      page: 1,
      per_page: 20,
      total: 0
    })

    const form = reactive({
      name: '',
      sku: '',
      price: 0,
      cost: 0,
      quantity: 0,
      min_quantity: 0,
      category_id: null,
      description: '',
      is_active: true,
      image: null,
      imagePreview: null
    })

    const rules = {
      name: [{ required: true, message: 'الاسم مطلوب', trigger: 'blur' }],
      sku: [{ required: true, message: 'SKU مطلوب', trigger: 'blur' }],
      price: [{ required: true, message: 'السعر مطلوب', trigger: 'blur' }],
      cost: [{ required: true, message: 'التكلفة مطلوبة', trigger: 'blur' }]
    }

    const formatPrice = (price) => {
      return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price)
    }

    const fetchProducts = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/admin/products', {
          params: {
            page: pagination.page,
            per_page: pagination.per_page,
            search: filters.search,
            category_id: filters.category_id,
            status: filters.status
          }
        })
        products.value = response.data.data
        pagination.total = response.data.total
      } catch (error) {
        console.error('Failed to fetch products:', error)
        ElMessage.error('فشل في تحميل المنتجات')
      } finally {
        loading.value = false
      }
    }

    const fetchCategories = async () => {
      try {
        const response = await axios.get('/api/admin/categories')
        categories.value = response.data
      } catch (error) {
        console.error('Failed to fetch categories:', error)
      }
    }

    const handleImageUpload = (event) => {
      const file = event.target.files[0]
      if (file) {
        form.image = file
        const reader = new FileReader()
        reader.onload = (e) => {
          form.imagePreview = e.target.result
        }
        reader.readAsDataURL(file)
      }
    }

    const openAddDialog = () => {
      editingId.value = null
      dialogTitle.value = 'إضافة منتج'
      resetForm()
      dialogVisible.value = true
    }

    const editProduct = (product) => {
      editingId.value = product.id
      dialogTitle.value = 'تعديل منتج'
      Object.assign(form, {
        name: product.name,
        sku: product.sku,
        price: product.price,
        cost: product.cost,
        quantity: product.quantity,
        min_quantity: product.min_quantity,
        category_id: product.category_id,
        description: product.description,
        is_active: product.is_active,
        image: null,
        imagePreview: product.image
      })
      dialogVisible.value = true
    }

    const saveProduct = async () => {
      const valid = await formRef.value?.validate()
      if (!valid) return

      saving.value = true
      try {
        const formData = new FormData()
        Object.keys(form).forEach(key => {
          if (form[key] !== null && key !== 'imagePreview') {
            formData.append(key, form[key])
          }
        })
        if (form.image) {
          formData.append('image', form.image)
        }

        if (editingId.value) {
          formData.append('_method', 'PUT')
          await axios.post(`/api/admin/products/${editingId.value}`, formData)
          ElMessage.success('تم تحديث المنتج بنجاح')
        } else {
          await axios.post('/api/admin/products', formData)
          ElMessage.success('تم إضافة المنتج بنجاح')
        }
        dialogVisible.value = false
        fetchProducts()
      } catch (error) {
        console.error('Failed to save product:', error)
        ElMessage.error('فشل في حفظ المنتج')
      } finally {
        saving.value = false
      }
    }

    const deleteProduct = async (product) => {
      ElMessageBox.confirm(`هل أنت متأكد من حذف المنتج "${product.name}"؟`, 'تأكيد الحذف', {
        confirmButtonText: 'حذف',
        cancelButtonText: 'إلغاء',
        type: 'warning'
      }).then(async () => {
        try {
          await axios.delete(`/api/admin/products/${product.id}`)
          ElMessage.success('تم حذف المنتج بنجاح')
          fetchProducts()
        } catch (error) {
          console.error('Failed to delete product:', error)
          ElMessage.error('فشل في حذف المنتج')
        }
      })
    }

    const resetForm = () => {
      Object.assign(form, {
        name: '',
        sku: '',
        price: 0,
        cost: 0,
        quantity: 0,
        min_quantity: 0,
        category_id: null,
        description: '',
        is_active: true,
        image: null,
        imagePreview: null
      })
    }

    onMounted(() => {
      fetchProducts()
      fetchCategories()
    })

    return {
      products,
      categories,
      loading,
      saving,
      dialogVisible,
      dialogTitle,
      filters,
      pagination,
      form,
      rules,
      formRef,
      formatPrice,
      fetchProducts,
      handleImageUpload,
      openAddDialog,
      editProduct,
      saveProduct,
      deleteProduct
    }
  }
}
</script>

<style scoped>
.products {
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}
.filter-card {
  margin-bottom: 20px;
}
.product-image {
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 8px;
}
.low-stock {
  color: #f56c6c;
  font-weight: bold;
}
.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
.image-preview {
  margin-top: 10px;
}
</style>
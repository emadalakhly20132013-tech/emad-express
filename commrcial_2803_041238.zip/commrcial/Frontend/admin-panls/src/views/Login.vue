<template>
  <div class="login-container">
    <el-card class="login-card">
      <div class="logo-area">
        <img src="@/assets/images/logo.png" class="login-logo">
        <h2>عماد إكسبرس</h2>
        <p>نظام إدارة المتجر الإلكتروني</p>
      </div>
      <el-form :model="form" :rules="rules" ref="formRef">
        <el-form-item prop="email">
          <el-input v-model="form.email" placeholder="البريد الإلكتروني" prefix-icon="User" />
        </el-form-item>
        <el-form-item prop="password">
          <el-input v-model="form.password" type="password" placeholder="كلمة المرور" prefix-icon="Lock" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleLogin" class="login-btn">تسجيل الدخول</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';
import { ElMessage } from 'element-plus';

export default {
  setup() {
    const router = useRouter();
    const formRef = ref(null);
    const form = reactive({ email: '', password: '' });
    const rules = {
      email: [{ required: true, message: 'البريد الإلكتروني مطلوب', trigger: 'blur' }],
      password: [{ required: true, message: 'كلمة المرور مطلوبة', trigger: 'blur' }],
    };

    const handleLogin = async () => {
      const valid = await formRef.value?.validate();
      if (!valid) return;
      try {
        const response = await axios.post('/api/auth/login', form);
        localStorage.setItem('access_token', response.data.access_token);
        localStorage.setItem('user', JSON.stringify(response.data.user));
        ElMessage.success('تم تسجيل الدخول بنجاح');
        router.push('/');
      } catch (error) {
        ElMessage.error('فشل تسجيل الدخول');
      }
    };

    return { form, rules, formRef, handleLogin };
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
.login-card { width: 400px; padding: 30px; border-radius: 20px; }
.logo-area { text-align: center; margin-bottom: 30px; }
.login-logo { width: 80px; height: 80px; border-radius: 40px; margin-bottom: 15px; }
.logo-area h2 { color: #0A66C2; margin: 0; }
.logo-area p { color: #666; font-size: 14px; margin-top: 5px; }
.login-btn { width: 100%; }
</style>
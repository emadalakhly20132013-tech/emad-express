<template>
  <div class="reports">
    <div class="header">
      <h2>التقارير</h2>
    </div>

    <el-row :gutter="20">
      <el-col :span="8">
        <el-card class="report-card" @click="selectReport('sales')">
          <div class="report-icon">
            <el-icon :size="48"><TrendCharts /></el-icon>
          </div>
          <h3>تقرير المبيعات</h3>
          <p>تحليل المبيعات حسب الفترة والمنتج والفئة</p>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="report-card" @click="selectReport('inventory')">
          <div class="report-icon">
            <el-icon :size="48"><Box /></el-icon>
          </div>
          <h3>تقرير المخزون</h3>
          <p>حالة المخزون والمنتجات منخفضة الكمية</p>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="report-card" @click="selectReport('customers')">
          <div class="report-icon">
            <el-icon :size="48"><User /></el-icon>
          </div>
          <h3>تقرير العملاء</h3>
          <p>تحليل سلوك العملاء وأكثر العملاء نشاطاً</p>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="mt-4">
      <el-col :span="8">
        <el-card class="report-card" @click="selectReport('vendors')">
          <div class="report-icon">
            <el-icon :size="48"><Shop /></el-icon>
          </div>
          <h3>تقرير البائعين</h3>
          <p>أداء البائعين والمبيعات حسب البائع</p>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="report-card" @click="selectReport('products')">
          <div class="report-icon">
            <el-icon :size="48"><Goods /></el-icon>
          </div>
          <h3>تقرير المنتجات</h3>
          <p>أكثر المنتجات مبيعاً والأعلى ربحية</p>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="report-card" @click="selectReport('profit')">
          <div class="report-icon">
            <el-icon :size="48"><Coin /></el-icon>
          </div>
          <h3>تقرير الأرباح</h3>
          <p>تحليل الأرباح حسب الفئة والمنتج</p>
        </el-card>
      </el-col>
    </el-row>

    <!-- Report Dialog -->
    <el-dialog :title="`تقرير ${reportTitle}`" v-model="dialogVisible" width="900px" @close="closeDialog">
      <div v-if="selectedReport === 'sales'">
        <el-form :inline="true" class="mb-3">
          <el-form-item label="من">
            <el-date-picker v-model="salesFilters.start_date" type="date" />
          </el-form-item>
          <el-form-item label="إلى">
            <el-date-picker v-model="salesFilters.end_date" type="date" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchSalesReport">عرض</el-button>
            <el-button @click="exportReport">تصدير Excel</el-button>
          </el-form-item>
        </el-form>
        <div v-if="salesReport">
          <el-row :gutter="20" class="mb-3">
            <el-col :span="6">
              <div class="stat-box">
                <div class="stat-label">إجمالي المبيعات</div>
                <div class="stat-value">{{ formatPrice(salesReport.total_sales) }}</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="stat-box">
                <div class="stat-label">عدد الطلبات</div>
                <div class="stat-value">{{ salesReport.total_orders }}</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="stat-box">
                <div class="stat-label">متوسط قيمة الطلب</div>
                <div class="stat-value">{{ formatPrice(salesReport.average_order_value) }}</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="stat-box">
                <div class="stat-label">هامش الربح</div>
                <div class="stat-value">{{ salesReport.profit_margin?.toFixed(2) }}%</div>
              </div>
            </el-col>
          </el-row>
          <div ref="salesChart" style="height: 300px"></div>
        </div>
      </div>

      <div v-if="selectedReport === 'inventory'">
        <el-form :inline="true" class="mb-3">
          <el-form-item>
            <el-button type="primary" @click="fetchInventoryReport">عرض</el-button>
            <el-button @click="exportReport">تصدير Excel</el-button>
          </el-form-item>
        </el-form>
        <div v-if="inventoryReport">
          <el-table :data="inventoryReport.low_stock" style="width: 100%">
            <el-table-column prop="name" label="المنتج" />
            <el-table-column prop="sku" label="SKU" />
            <el-table-column prop="quantity" label="الكمية" />
            <el-table-column prop="min_quantity" label="الحد الأدنى" />
          </el-table>
        </div>
      </div>

      <div v-if="selectedReport === 'customers'">
        <el-form :inline="true" class="mb-3">
          <el-form-item>
            <el-button type="primary" @click="fetchCustomersReport">عرض</el-button>
            <el-button @click="exportReport">تصدير Excel</el-button>
          </el-form-item>
        </el-form>
        <div v-if="customersReport">
          <el-table :data="customersReport.top_customers" style="width: 100%">
            <el-table-column prop="name" label="العميل" />
            <el-table-column prop="email" label="البريد الإلكتروني" />
            <el-table-column prop="total_orders" label="عدد الطلبات" />
            <el-table-column prop="total_spent" label="إجمالي المشتريات">
              <template #default="{ row }">
                {{ formatPrice(row.total_spent) }}
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import * as echarts from 'echarts'
import { ElMessage } from 'element-plus'

export default {
  name: 'Reports',
  setup() {
    const dialogVisible = ref(false)
    const selectedReport = ref('')
    const reportTitle = ref('')
    const salesFilters = ref({ start_date: null, end_date: null })
    const salesReport = ref(null)
    const inventoryReport = ref(null)
    const customersReport = ref(null)
    let salesChart = null

    const formatPrice = (price) => {
      return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price || 0)
    }

    const selectReport = (type) => {
      selectedReport.value = type
      const titles = {
        sales: 'المبيعات',
        inventory: 'المخزون',
        customers: 'العملاء',
        vendors: 'البائعين',
        products: 'المنتجات',
        profit: 'الأرباح'
      }
      reportTitle.value = titles[type]
      dialogVisible.value = true
    }

    const fetchSalesReport = async () => {
      try {
        const response = await axios.get('/api/reports/sales', {
          params: {
            start_date: salesFilters.value.start_date,
            end_date: salesFilters.value.end_date
          }
        })
        salesReport.value = response.data
        setTimeout(() => initSalesChart(), 100)
      } catch (error) {
        console.error('Failed to fetch sales report:', error)
        ElMessage.error('فشل في تحميل التقرير')
      }
    }

    const initSalesChart = () => {
      const chartEl = document.querySelector('#salesChart')
      if (chartEl && salesReport.value?.daily_sales) {
        if (salesChart) salesChart.dispose()
        salesChart = echarts.init(chartEl)
        salesChart.setOption({
          tooltip: { trigger: 'axis' },
          xAxis: { type: 'category', data: salesReport.value.daily_sales.map(s => s.date) },
          yAxis: { type: 'value', name: 'المبيعات (ريال)' },
          series: [{ type: 'line', data: salesReport.value.daily_sales.map(s => s.amount), smooth: true, areaStyle: {} }]
        })
      }
    }

    const fetchInventoryReport = async () => {
      try {
        const response = await axios.get('/api/reports/inventory')
        inventoryReport.value = response.data
      } catch (error) {
        console.error('Failed to fetch inventory report:', error)
        ElMessage.error('فشل في تحميل التقرير')
      }
    }

    const fetchCustomersReport = async () => {
      try {
        const response = await axios.get('/api/reports/customers')
        customersReport.value = response.data
      } catch (error) {
        console.error('Failed to fetch customers report:', error)
        ElMessage.error('فشل في تحميل التقرير')
      }
    }

    const exportReport = () => {
      ElMessage.info('سيتم إضافة تصدير Excel قريباً')
    }

    const closeDialog = () => {
      if (salesChart) salesChart.dispose()
      salesReport.value = null
      inventoryReport.value = null
      customersReport.value = null
    }

    return {
      dialogVisible,
      selectedReport,
      reportTitle,
      salesFilters,
      salesReport,
      inventoryReport,
      customersReport,
      formatPrice,
      selectReport,
      fetchSalesReport,
      fetchInventoryReport,
      fetchCustomersReport,
      exportReport,
      closeDialog
    }
  }
}
</script>

<style scoped>
.reports {
  padding: 20px;
}
.header {
  margin-bottom: 30px;
}
.report-card {
  text-align: center;
  cursor: pointer;
  transition: transform 0.3s;
}
.report-card:hover {
  transform: translateY(-5px);
}
.report-icon {
  margin-bottom: 15px;
  color: #409eff;
}
.report-card h3 {
  margin: 10px 0;
}
.report-card p {
  color: #909399;
  font-size: 14px;
}
.mt-4 {
  margin-top: 20px;
}
.mb-3 {
  margin-bottom: 15px;
}
.stat-box {
  text-align: center;
  padding: 15px;
  background: #f5f7fa;
  border-radius: 8px;
}
.stat-label {
  font-size: 14px;
  color: #909399;
}
.stat-value {
  font-size: 24px;
  font-weight: bold;
  margin-top: 5px;
}
</style>
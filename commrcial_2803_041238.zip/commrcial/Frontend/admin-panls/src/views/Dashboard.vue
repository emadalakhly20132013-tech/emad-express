<template>
  <div class="dashboard">
    <el-row :gutter="20">
      <el-col :span="6" v-for="stat in stats" :key="stat.title">
        <el-card class="stat-card" :style="{ background: stat.color }">
          <div class="stat-icon">
            <el-icon :size="40"><component :is="stat.icon" /></el-icon>
          </div>
          <div class="stat-content">
            <h3>{{ stat.value }}</h3>
            <p>{{ stat.title }}</p>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="mt-4">
      <el-col :span="12">
        <el-card>
          <template #header>
            <span>المبيعات اليومية</span>
          </template>
          <div ref="salesChart" style="height: 300px"></div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <template #header>
            <span>المنتجات الأكثر مبيعاً</span>
          </template>
          <el-table :data="topProducts" style="width: 100%">
            <el-table-column prop="name" label="المنتج" />
            <el-table-column prop="sold_count" label="عدد المبيعات" />
            <el-table-column prop="revenue" label="الإيرادات" />
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <el-row class="mt-4">
      <el-col :span="24">
        <el-card>
          <template #header>
            <span>آخر الطلبات</span>
          </template>
          <el-table :data="recentOrders" style="width: 100%">
            <el-table-column prop="order_number" label="رقم الطلب" />
            <el-table-column prop="customer_name" label="العميل" />
            <el-table-column prop="total" label="الإجمالي" />
            <el-table-column prop="status" label="الحالة">
              <template #default="{ row }">
                <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'
import axios from 'axios'

export default {
  name: 'Dashboard',
  setup() {
    const stats = ref([
      { title: 'إجمالي المبيعات', value: '0 ريال', icon: 'Money', color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
      { title: 'عدد الطلبات', value: '0', icon: 'ShoppingCart', color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' },
      { title: 'عدد العملاء', value: '0', icon: 'User', color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' },
      { title: 'عدد المنتجات', value: '0', icon: 'Goods', color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)' },
    ])
    
    const topProducts = ref([])
    const recentOrders = ref([])
    const salesChart = ref(null)

    const getStatusType = (status) => {
      const types = {
        pending: 'warning',
        processing: 'info',
        shipped: 'primary',
        delivered: 'success',
        cancelled: 'danger'
      }
      return types[status] || 'info'
    }

    const fetchData = async () => {
      try {
        const response = await axios.get('/api/admin/dashboard')
        const data = response.data
        stats.value[0].value = `${data.total_sales} ريال`
        stats.value[1].value = data.total_orders
        stats.value[2].value = data.total_customers
        stats.value[3].value = data.total_products
        topProducts.value = data.top_products
        recentOrders.value = data.recent_orders
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error)
      }
    }

    const initChart = () => {
      const chart = echarts.init(salesChart.value)
      chart.setOption({
        tooltip: { trigger: 'axis' },
        xAxis: { type: 'category', data: ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'] },
        yAxis: { type: 'value', name: 'المبيعات (ريال)' },
        series: [{ type: 'line', data: [1200, 1500, 1800, 2200, 2600, 3100, 2800], smooth: true }]
      })
    }

    onMounted(() => {
      fetchData()
      initChart()
    })

    return { stats, topProducts, recentOrders, getStatusType, salesChart }
  }
}
</script>

<style scoped>
.stat-card {
  display: flex;
  align-items: center;
  padding: 20px;
  border-radius: 15px;
  color: white;
}
.stat-icon {
  flex: 0 0 60px;
}
.stat-content {
  flex: 1;
  text-align: right;
}
.stat-content h3 {
  font-size: 28px;
  margin: 0;
}
.stat-content p {
  margin: 5px 0 0;
  opacity: 0.9;
}
.mt-4 {
  margin-top: 20px;
}
</style>
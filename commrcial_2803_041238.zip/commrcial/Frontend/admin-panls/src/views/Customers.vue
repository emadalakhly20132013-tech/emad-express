<template>
  <div class="customers">
    <div class="header">
      <h2>العملاء</h2>
    </div>

    <el-card class="filter-card">
      <el-form :inline="true" :model="filters">
        <el-form-item label="البحث">
          <el-input v-model="filters.search" placeholder="الاسم أو البريد الإلكتروني" clearable @clear="fetchCustomers" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchCustomers">بحث</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-table :data="customers" style="width: 100%" v-loading="loading">
      <el-table-column prop="name" label="الاسم" />
      <el-table-column prop="email" label="البريد الإلكتروني" />
      <el-table-column prop="phone" label="الهاتف" />
      <el-table-column prop="total_orders" label="عدد الطلبات" />
      <el-table-column prop="total_spent" label="إجمالي المشتريات">
        <template #default="{ row }">
          {{ formatPrice(row.total_spent) }}
        </template>
      </el-table-column>
      <el-table-column prop="loyalty_points" label="نقاط الولاء" />
      <el-table-column prop="created_at" label="تاريخ التسجيل">
        <template #default="{ row }">
          {{ formatDate(row.created_at) }}
        </template>
      </el-table-column>
      <el-table-column label="الإجراءات">
        <template #default="{ row }">
          <el-button type="primary" size="small" @click="viewCustomer(row)">عرض التفاصيل</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      v-model:current-page="pagination.page"
      v-model:page-size="pagination.per_page"
      :total="pagination.total"
      layout="total, prev, pager, next"
      @current-change="fetchCustomers"
      class="pagination"
    />

    <!-- Customer Details Dialog -->
    <el-dialog :title="`تفاصيل العميل ${selectedCustomer?.name}`" v-model="dialogVisible" width="800px">
      <div v-if="selectedCustomer">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="الاسم">{{ selectedCustomer.name }}</el-descriptions-item>
          <el-descriptions-item label="البريد الإلكتروني">{{ selectedCustomer.email }}</el-descriptions-item>
          <el-descriptions-item label="الهاتف">{{ selectedCustomer.phone }}</el-descriptions-item>
          <el-descriptions-item label="العنوان">{{ selectedCustomer.address || '-' }}</el-descriptions-item>
          <el-descriptions-item label="نقاط الولاء">{{ selectedCustomer.loyalty_points }}</el-descriptions-item>
          <el-descriptions-item label="تاريخ التسجيل">{{ formatDate(selectedCustomer.created_at) }}</el-descriptions-item>
        </el-descriptions>

        <el-divider>آخر الطلبات</el-divider>
        <el-table :data="selectedCustomer.recent_orders" style="width: 100%">
          <el-table-column prop="order_number" label="رقم الطلب" />
          <el-table-column prop="total" label="الإجمالي">
            <template #default="{ row }">
              {{ formatPrice(row.total) }}
            </template>
          </el-table-column>
          <el-table-column prop="status" label="الحالة" />
          <el-table-column prop="created_at" label="التاريخ">
            <template #default="{ row }">
              {{ formatDate(row.created_at) }}
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage } from 'element-plus'

export default {
  name: 'Customers',
  setup() {
    const customers = ref([])
    const loading = ref(false)
    const dialogVisible = ref(false)
    const selectedCustomer = ref(null)

    const filters = reactive({
      search: ''
    })

    const pagination = reactive({
      page: 1,
      per_page: 20,
      total: 0
    })

    const formatPrice = (price) => {
      return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price || 0)
    }

    const formatDate = (date) => {
      return new Date(date).toLocaleDateString('ar-SA')
    }

    const fetchCustomers = async () => {
      loading.value = true
      try {
        const response = await axios.get('/api/admin/customers', {
          params: {
            page: pagination.page,
            per_page: pagination.per_page,
            search: filters.search
          }
        })
        customers.value = response.data.data
        pagination.total = response.data.total
      } catch (error) {
        console.error('Failed to fetch customers:', error)
        ElMessage.error('فشل في تحميل العملاء')
      } finally {
        loading.value = false
      }
    }

    const viewCustomer = async (customer) => {
      try {
        const response = await axios.get(`/api/admin/customers/${customer.id}`)
        selectedCustomer.value = response.data
        dialogVisible.value = true
      } catch (error) {
        console.error('Failed to fetch customer details:', error)
        ElMessage.error('فشل في تحميل تفاصيل العميل')
      }
    }

    onMounted(() => {
      fetchCustomers()
    })

    return {
      customers,
      loading,
      dialogVisible,
      selectedCustomer,
      filters,
      pagination,
      formatPrice,
      formatDate,
      fetchCustomers,
      viewCustomer
    }
  }
}
</script>

<style scoped>
.customers {
  padding: 20px;
}
.header {
  margin-bottom: 20px;
}
.filter-card {
  margin-bottom: 20px;
}
.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>
<template>
  <div class="accounting">
    <div class="header">
      <h2>المحاسبة</h2>
      <el-radio-group v-model="reportType" @change="fetchReport">
        <el-radio-button label="balance">الميزانية العمومية</el-radio-button>
        <el-radio-button label="income">قائمة الدخل</el-radio-button>
        <el-radio-button label="cashflow">التدفقات النقدية</el-radio-button>
        <el-radio-button label="trial">ميزان المراجعة</el-radio-button>
      </el-radio-group>
    </div>

    <el-card class="filter-card">
      <el-form :inline="true">
        <el-form-item label="التاريخ">
          <el-date-picker v-model="date" type="date" placeholder="اختر التاريخ" @change="fetchReport" />
        </el-form-item>
        <el-form-item v-if="reportType === 'income'" label="الفترة">
          <el-date-picker v-model="dateRange" type="daterange" range-separator="إلى" @change="fetchReport" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="exportReport">تصدير PDF</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- Balance Sheet -->
    <el-card v-if="reportType === 'balance' && balanceSheet">
      <h3>الميزانية العمومية</h3>
      <p class="date">بتاريخ: {{ formatDate(balanceSheet.date) }}</p>
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="report-section">
            <h4>الأصول</h4>
            <div class="total-amount">{{ formatPrice(balanceSheet.assets) }}</div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="report-section">
            <h4>الخصوم وحقوق الملكية</h4>
            <div>الخصوم: {{ formatPrice(balanceSheet.liabilities) }}</div>
            <div>حقوق الملكية: {{ formatPrice(balanceSheet.equity) }}</div>
            <div class="total-amount mt-2">الإجمالي: {{ formatPrice(balanceSheet.total_liabilities_equity) }}</div>
          </div>
        </el-col>
      </el-row>
      <el-alert v-if="!balanceSheet.is_balanced" type="error" title="الميزانية غير متوازنة!" class="mt-3" />
    </el-card>

    <!-- Income Statement -->
    <el-card v-if="reportType === 'income' && incomeStatement">
      <h3>قائمة الدخل</h3>
      <p>من {{ formatDate(incomeStatement.start_date) }} إلى {{ formatDate(incomeStatement.end_date) }}</p>
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="report-section">
            <h4>الإيرادات</h4>
            <div class="total-amount">{{ formatPrice(incomeStatement.revenues) }}</div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="report-section">
            <h4>المصروفات</h4>
            <div class="total-amount">{{ formatPrice(incomeStatement.expenses) }}</div>
          </div>
        </el-col>
      </el-row>
      <div class="report-section mt-3" :class="incomeStatement.net_income >= 0 ? 'profit' : 'loss'">
        <h4>صافي الربح/الخسارة</h4>
        <div class="total-amount">{{ formatPrice(Math.abs(incomeStatement.net_income)) }}</div>
        <p>{{ incomeStatement.net_income >= 0 ? 'ربح' : 'خسارة' }}</p>
        <p>هامش الربح: {{ incomeStatement.profit_margin?.toFixed(2) }}%</p>
      </div>
    </el-card>

    <!-- Cash Flow -->
    <el-card v-if="reportType === 'cashflow' && cashFlow">
      <h3>قائمة التدفقات النقدية</h3>
      <p>من {{ formatDate(cashFlow.start_date) }} إلى {{ formatDate(cashFlow.end_date) }}</p>
      <div class="report-section">
        <h4>الرصيد الافتتاحي</h4>
        <div>{{ formatPrice(cashFlow.opening_balance) }}</div>
        <h4 class="mt-2">الرصيد الختامي</h4>
        <div class="total-amount">{{ formatPrice(cashFlow.closing_balance) }}</div>
        <h4 class="mt-2">صافي التغير</h4>
        <div :class="cashFlow.net_change >= 0 ? 'profit' : 'loss'">
          {{ formatPrice(cashFlow.net_change) }}
        </div>
      </div>
    </el-card>

    <!-- Trial Balance -->
    <el-card v-if="reportType === 'trial' && trialBalance">
      <h3>ميزان المراجعة</h3>
      <p>بتاريخ: {{ formatDate(trialBalance.date) }}</p>
      <el-table :data="trialBalance.accounts" style="width: 100%">
        <el-table-column prop="code" label="رقم الحساب" />
        <el-table-column prop="name" label="اسم الحساب" />
        <el-table-column prop="debit" label="مدين">
          <template #default="{ row }">
            {{ formatPrice(row.debit) }}
          </template>
        </el-table-column>
        <el-table-column prop="credit" label="دائن">
          <template #default="{ row }">
            {{ formatPrice(row.credit) }}
          </template>
        </el-table-column>
      </el-table>
      <div class="summary mt-3">
        <div>إجمالي المدين: {{ formatPrice(trialBalance.total_debit) }}</div>
        <div>إجمالي الدائن: {{ formatPrice(trialBalance.total_credit) }}</div>
        <el-alert v-if="!trialBalance.is_balanced" type="error" title="الميزان غير متوازن!" class="mt-2" />
      </div>
    </el-card>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage } from 'element-plus'

export default {
  name: 'Accounting',
  setup() {
    const reportType = ref('balance')
    const date = ref(new Date())
    const dateRange = ref([new Date(new Date().getFullYear(), 0, 1), new Date()])
    
    const balanceSheet = ref(null)
    const incomeStatement = ref(null)
    const cashFlow = ref(null)
    const trialBalance = ref(null)

    const formatPrice = (price) => {
      return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price || 0)
    }

    const formatDate = (date) => {
      if (!date) return '-'
      return new Date(date).toLocaleDateString('ar-SA')
    }

    const fetchReport = async () => {
      try {
        if (reportType.value === 'balance') {
          const response = await axios.get('/api/accounting/balance-sheet', {
            params: { as_of_date: date.value }
          })
          balanceSheet.value = response.data
        } else if (reportType.value === 'income') {
          const response = await axios.get('/api/accounting/income-statement', {
            params: {
              start_date: dateRange.value[0],
              end_date: dateRange.value[1]
            }
          })
          incomeStatement.value = response.data
        } else if (reportType.value === 'cashflow') {
          const response = await axios.get('/api/accounting/cash-flow', {
            params: {
              start_date: dateRange.value[0],
              end_date: dateRange.value[1]
            }
          })
          cashFlow.value = response.data
        } else if (reportType.value === 'trial') {
          const response = await axios.get('/api/accounting/trial-balance', {
            params: { as_of_date: date.value }
          })
          trialBalance.value = response.data
        }
      } catch (error) {
        console.error('Failed to fetch report:', error)
        ElMessage.error('فشل في تحميل التقرير')
      }
    }

    const exportReport = () => {
      ElMessage.info('سيتم إضافة تصدير PDF قريباً')
    }

    onMounted(() => {
      fetchReport()
    })

    return {
      reportType,
      date,
      dateRange,
      balanceSheet,
      incomeStatement,
      cashFlow,
      trialBalance,
      formatPrice,
      formatDate,
      fetchReport,
      exportReport
    }
  }
}
</script>

<style scoped>
.accounting {
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}
.filter-card {
  margin-bottom: 20px;
}
.report-section {
  text-align: center;
  padding: 20px;
  background: #f5f7fa;
  border-radius: 12px;
  margin-bottom: 15px;
}
.report-section h4 {
  margin: 0 0 10px;
  color: #409eff;
}
.total-amount {
  font-size: 28px;
  font-weight: bold;
  margin: 10px 0;
}
.profit {
  color: #67c23a;
}
.loss {
  color: #f56c6c;
}
.mt-2 {
  margin-top: 10px;
}
.mt-3 {
  margin-top: 15px;
}
</style>
export const endpoints = {
  login: '/auth/login',
  register: '/auth/register',
  products: '/products',
  productDetail: (id) => `/products/${id}`,
  categories: '/categories',
  orders: '/orders',
  orderDetail: (id) => `/orders/${id}`,
  createOrder: '/orders',
};
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 🔴 غيّر هذا السطر حسب جهازك:
const API_BASE_URL = 'http://10.0.2.2:8000/api';  // لمحاكي Android
// const API_BASE_URL = 'http://localhost:8000/api';  // لمحاكي iOS
// const API_BASE_URL = 'http://192.168.1.100:8000/api';  // لجهاز حقيقي

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 10000,
});

apiClient.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await AsyncStorage.removeItem('access_token');
      await AsyncStorage.removeItem('user');
    }
    return Promise.reject(error);
  }
);

export default apiClient;
export const formatPrice = (price) => {
  return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price);
};

export const formatDate = (date) => {
  return new Date(date).toLocaleDateString('ar-SA');
};

export const formatDateTime = (date) => {
  return new Date(date).toLocaleString('ar-SA');
};
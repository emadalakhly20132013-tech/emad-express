import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView, ActivityIndicator } from 'react-native';
import { useAuth } from '../store/authStore';
import useCartStore from '../store/cartStore';
import apiClient from '../api/client';
import { endpoints } from '../api/endpoints';
import BackgroundWrapper from '../components/BackgroundWrapper';

const formatPrice = (price) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price);

const CheckoutScreen = ({ navigation }) => {
  const { user } = useAuth();
  const { items, clearCart, getTotal } = useCartStore();
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);

  const total = getTotal();
  const tax = total * 0.15;
  const grandTotal = total + tax;

  const placeOrder = async () => {
    if (!address.trim()) {
      Alert.alert('خطأ', 'الرجاء إدخال عنوان الشحن');
      return;
    }
    setLoading(true);
    try {
      const orderData = {
        items: items.map((item) => ({ product_id: item.id, quantity: item.quantity })),
        payment_method: 'cod',
        shipping_address: address,
      };
      const response = await apiClient.post(endpoints.createOrder, orderData);
      Alert.alert('تم الطلب', `رقم الطلب: ${response.data.order_number}`, [
        { text: 'OK', onPress: () => { clearCart(); navigation.navigate('OrdersTab'); } }
      ]);
    } catch (error) {
      Alert.alert('خطأ', error.response?.data?.message || 'فشل في إنشاء الطلب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <BackgroundWrapper>
      <ScrollView style={styles.container}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>معلومات الشحن</Text>
          <TextInput style={styles.input} placeholder="عنوان الشحن" value={address} onChangeText={setAddress} multiline numberOfLines={3} />
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ملخص الطلب</Text>
          <View style={styles.summaryRow}><Text>المجموع الفرعي</Text><Text>{formatPrice(total)}</Text></View>
          <View style={styles.summaryRow}><Text>الضريبة (15%)</Text><Text>{formatPrice(tax)}</Text></View>
          <View style={[styles.summaryRow, styles.totalRow]}><Text style={styles.totalLabel}>الإجمالي</Text><Text style={styles.totalValue}>{formatPrice(grandTotal)}</Text></View>
        </View>
        <TouchableOpacity style={styles.placeOrderButton} onPress={placeOrder} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.placeOrderButtonText}>تأكيد الطلب</Text>}
        </TouchableOpacity>
      </ScrollView>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  section: { backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 12, padding: 16, marginBottom: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12, borderBottomWidth: 1, borderBottomColor: '#eee', paddingBottom: 8 },
  input: { backgroundColor: '#f5f5f5', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, minHeight: 80, textAlignVertical: 'top' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 },
  totalRow: { borderTopWidth: 1, borderTopColor: '#eee', marginTop: 8, paddingTop: 12 },
  totalLabel: { fontSize: 16, fontWeight: 'bold' },
  totalValue: { fontSize: 18, fontWeight: 'bold', color: '#f00' },
  placeOrderButton: { backgroundColor: '#007AFF', borderRadius: 10, paddingVertical: 14, alignItems: 'center', marginTop: 16, marginBottom: 32 },
  placeOrderButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

export default CheckoutScreen;
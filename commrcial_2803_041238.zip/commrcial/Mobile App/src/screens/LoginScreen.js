import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../store/authStore';
import BackgroundWrapper from '../components/BackgroundWrapper';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('خطأ', 'الرجاء إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (!result.success) Alert.alert('خطأ', result.message);
  };

  return (
    <BackgroundWrapper>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
        <View style={styles.logoContainer}>
          <Image source={require('../assets/images/logo.png')} style={styles.logo} />
          <Text style={styles.appName}>عماد إكسبرس</Text>
          <Text style={styles.tagline}>تسوق بكل سهولة</Text>
        </View>
        <View style={styles.formContainer}>
          <TextInput style={styles.input} placeholder="البريد الإلكتروني" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
          <TextInput style={styles.input} placeholder="كلمة المرور" value={password} onChangeText={setPassword} secureTextEntry />
          <TouchableOpacity style={styles.loginButton} onPress={handleLogin} disabled={loading}>
            <Text style={styles.loginButtonText}>{loading ? 'جاري التسجيل...' : 'تسجيل الدخول'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.registerText}>ليس لديك حساب؟ <Text style={styles.registerBold}>إنشاء حساب جديد</Text></Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', paddingHorizontal: 20 },
  logoContainer: { alignItems: 'center', marginBottom: 40 },
  logo: { width: 100, height: 100, borderRadius: 50, backgroundColor: '#fff' },
  appName: { fontSize: 28, fontWeight: 'bold', color: '#fff', marginTop: 10 },
  tagline: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: 5 },
  formContainer: { backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 15, padding: 20 },
  input: { backgroundColor: '#f5f5f5', borderRadius: 10, paddingHorizontal: 15, paddingVertical: 12, marginBottom: 15, fontSize: 16 },
  loginButton: { backgroundColor: '#007AFF', borderRadius: 10, paddingVertical: 14, alignItems: 'center', marginTop: 10 },
  loginButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  registerText: { color: '#666', fontSize: 14, textAlign: 'center', marginTop: 20 },
  registerBold: { color: '#007AFF', fontWeight: 'bold' },
});

export default LoginScreen;
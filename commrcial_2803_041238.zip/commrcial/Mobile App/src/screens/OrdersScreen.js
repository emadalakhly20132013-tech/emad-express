import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import apiClient from '../api/client';
import { endpoints } from '../api/endpoints';
import BackgroundWrapper from '../components/BackgroundWrapper';
import EmptyState from '../components/EmptyState';

const formatPrice = (price) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price);
const formatDate = (date) => new Date(date).toLocaleDateString('ar-SA');
const getStatusText = (status) => ({ pending: 'قيد الانتظار', processing: 'قيد المعالجة', shipped: 'تم الشحن', delivered: 'تم التسليم', cancelled: 'ملغي' }[status] || status);

const OrdersScreen = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchOrders(); }, []);

  const fetchOrders = async () => {
    try {
      const response = await apiClient.get(endpoints.orders);
      setOrders(response.data.data || []);
    } catch (error) { console.error(error); }
    finally { setLoading(false); }
  };

  if (loading) return <BackgroundWrapper><View style={styles.centered}><ActivityIndicator size="large" /></View></BackgroundWrapper>;
  if (orders.length === 0) return <BackgroundWrapper><EmptyState message="لا توجد طلبات سابقة" icon="📋" /></BackgroundWrapper>;

  return (
    <BackgroundWrapper>
      <View style={styles.container}>
        <Text style={styles.header}>عماد إكسبرس - طلباتي</Text>
        <FlatList data={orders} keyExtractor={(item) => item.id.toString()} renderItem={({ item }) => (
          <View style={styles.orderCard}>
            <View style={styles.orderHeader}><Text style={styles.orderNumber}>رقم: {item.order_number}</Text><Text>{formatDate(item.order_date)}</Text></View>
            <View style={styles.orderDetails}><Text style={styles.orderTotal}>{formatPrice(item.total)}</Text><Text style={[styles.orderStatus, { color: item.status === 'delivered' ? '#4caf50' : item.status === 'cancelled' ? '#f44336' : '#ff9800' }]}>{getStatusText(item.status)}</Text></View>
          </View>
        )} />
      </View>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { fontSize: 18, fontWeight: 'bold', color: '#fff', textAlign: 'center', paddingVertical: 12, backgroundColor: 'rgba(0,0,0,0.5)' },
  orderCard: { backgroundColor: '#fff', borderRadius: 10, padding: 12, margin: 12, marginBottom: 8 },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#eee', paddingBottom: 8, marginBottom: 8 },
  orderNumber: { fontSize: 14, fontWeight: 'bold' },
  orderDetails: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderTotal: { fontSize: 16, fontWeight: 'bold', color: '#f00' },
  orderStatus: { fontSize: 12, fontWeight: 'bold' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

export default OrdersScreen;
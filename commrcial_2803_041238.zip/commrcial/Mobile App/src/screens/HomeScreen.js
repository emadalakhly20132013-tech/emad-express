import React, { useState, useEffect } from 'react';
import { View, FlatList, StyleSheet, SafeAreaView, ActivityIndicator, Text } from 'react-native';
import ProductCard from '../components/ProductCard';
import CategoryList from '../components/CategoryList';
import BackgroundWrapper from '../components/BackgroundWrapper';
import apiClient from '../api/client';
import { endpoints } from '../api/endpoints';

const HomeScreen = ({ navigation }) => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingCategories, setLoadingCategories] = useState(true);

  useEffect(() => { fetchCategories(); }, []);
  useEffect(() => { if (!loadingCategories) fetchProducts(); }, [selectedCategory]);

  const fetchCategories = async () => {
    try {
      const response = await apiClient.get(endpoints.categories);
      setCategories(response.data);
    } catch (error) { console.error(error); }
    finally { setLoadingCategories(false); }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const params = selectedCategory ? { category_id: selectedCategory } : {};
      const response = await apiClient.get(endpoints.products, { params });
      setProducts(response.data.data || []);
    } catch (error) { console.error(error); }
    finally { setLoading(false); }
  };

  if (loadingCategories) return <BackgroundWrapper><View style={styles.centered}><ActivityIndicator size="large" /></View></BackgroundWrapper>;

  return (
    <BackgroundWrapper>
      <SafeAreaView style={styles.container}>
        <CategoryList categories={categories} selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
        {loading ? <ActivityIndicator size="large" color="#fff" /> : (
          <FlatList
            data={products}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => <ProductCard product={item} onPress={() => navigation.navigate('ProductDetail', { productId: item.id })} />}
            numColumns={2}
            columnWrapperStyle={styles.row}
            ListEmptyComponent={<Text style={styles.emptyText}>لا توجد منتجات في هذه الفئة</Text>}
          />
        )}
      </SafeAreaView>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  row: { justifyContent: 'space-between', paddingHorizontal: 8 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { textAlign: 'center', marginTop: 50, fontSize: 16, color: '#fff', backgroundColor: 'rgba(0,0,0,0.5)', padding: 10, borderRadius: 8 },
});

export default HomeScreen;
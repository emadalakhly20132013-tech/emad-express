import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet, Animated } from 'react-native';
import BackgroundWrapper from '../components/BackgroundWrapper';

const SplashScreen = ({ navigation }) => {
  const fadeAnim = new Animated.Value(0);
  const scaleAnim = new Animated.Value(0.5);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, tension: 10, useNativeDriver: true }),
    ]).start();

    setTimeout(() => navigation.replace('Home'), 2000);
  }, []);

  return (
    <BackgroundWrapper>
      <View style={styles.container}>
        <Animated.Image
          source={require('../assets/images/logo.png')}
          style={[styles.logo, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}
        />
        <Animated.Text style={[styles.appName, { opacity: fadeAnim }]}>عماد إكسبرس</Animated.Text>
        <Animated.Text style={[styles.tagline, { opacity: fadeAnim }]}>أسرع توصيل • تجربة مميزة</Animated.Text>
      </View>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  logo: { width: 120, height: 120, borderRadius: 60, backgroundColor: '#fff', marginBottom: 20 },
  appName: { fontSize: 28, fontWeight: 'bold', color: '#fff', marginTop: 10 },
  tagline: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: 5 },
});

export default SplashScreen;
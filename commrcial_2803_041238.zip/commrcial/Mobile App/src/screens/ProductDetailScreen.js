import React, { useState, useEffect } from 'react';
import { View, Text, Image, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import apiClient from '../api/client';
import { endpoints } from '../api/endpoints';
import useCartStore from '../store/cartStore';
import BackgroundWrapper from '../components/BackgroundWrapper';

const formatPrice = (price) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price);

const ProductDetailScreen = ({ route }) => {
  const { productId } = route.params;
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const addToCart = useCartStore((state) => state.addItem);

  useEffect(() => { fetchProduct(); }, []);

  const fetchProduct = async () => {
    try {
      const response = await apiClient.get(endpoints.productDetail(productId));
      setProduct(response.data.product);
    } catch (error) { Alert.alert('خطأ', 'فشل في تحميل المنتج'); }
    finally { setLoading(false); }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    Alert.alert('تم', 'تم إضافة المنتج إلى السلة');
  };

  if (loading) return <BackgroundWrapper><View style={styles.centered}><ActivityIndicator size="large" /></View></BackgroundWrapper>;
  if (!product) return <BackgroundWrapper><View style={styles.centered}><Text>المنتج غير موجود</Text></View></BackgroundWrapper>;

  return (
    <BackgroundWrapper>
      <ScrollView style={styles.container}>
        <Image source={{ uri: product.image }} style={styles.image} />
        <View style={styles.content}>
          <Text style={styles.name}>{product.name}</Text>
          <Text style={styles.price}>{formatPrice(product.price)}</Text>
          <Text style={styles.description}>{product.description}</Text>
          <View style={styles.quantityContainer}>
            <Text style={styles.quantityLabel}>الكمية:</Text>
            <View style={styles.quantityControls}>
              <TouchableOpacity style={styles.qtyButton} onPress={() => setQuantity(Math.max(1, quantity - 1))}><Text style={styles.qtyButtonText}>-</Text></TouchableOpacity>
              <Text style={styles.quantity}>{quantity}</Text>
              <TouchableOpacity style={styles.qtyButton} onPress={() => setQuantity(quantity + 1)}><Text style={styles.qtyButtonText}>+</Text></TouchableOpacity>
            </View>
          </View>
          <TouchableOpacity style={styles.addButton} onPress={handleAddToCart}><Text style={styles.addButtonText}>أضف إلى السلة</Text></TouchableOpacity>
        </View>
      </ScrollView>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  image: { width: '100%', height: 300, resizeMode: 'contain', backgroundColor: '#fff' },
  content: { padding: 16, backgroundColor: 'rgba(255,255,255,0.95)', borderTopLeftRadius: 20, borderTopRightRadius: 20 },
  name: { fontSize: 24, fontWeight: 'bold', color: '#333', marginBottom: 8 },
  price: { fontSize: 20, color: '#f00', fontWeight: 'bold', marginBottom: 16 },
  description: { fontSize: 14, color: '#666', lineHeight: 20, marginBottom: 20 },
  quantityContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  quantityLabel: { fontSize: 16, color: '#333' },
  quantityControls: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 25 },
  qtyButton: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  qtyButtonText: { fontSize: 20, fontWeight: 'bold', color: '#007AFF' },
  quantity: { width: 40, textAlign: 'center', fontSize: 16, fontWeight: 'bold' },
  addButton: { backgroundColor: '#007AFF', borderRadius: 10, paddingVertical: 14, alignItems: 'center' },
  addButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});

export default ProductDetailScreen;
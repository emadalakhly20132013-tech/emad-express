import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import { useAuth } from '../store/authStore';
import BackgroundWrapper from '../components/BackgroundWrapper';

const ProfileScreen = ({ navigation }) => {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert('تسجيل الخروج', 'هل أنت متأكد من تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'تسجيل الخروج', onPress: logout, style: 'destructive' },
    ]);
  };

  return (
    <BackgroundWrapper>
      <View style={styles.container}>
        <View style={styles.profileHeader}>
          <Image source={require('../assets/images/avatar.png')} style={styles.avatar} />
          <Text style={styles.userName}>{user?.name}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
          <Text style={styles.userPhone}>{user?.phone}</Text>
        </View>
        <View style={styles.menuContainer}>
          <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('OrdersList')}><Text style={styles.menuText}>طلباتي</Text></TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Settings')}><Text style={styles.menuText}>الإعدادات</Text></TouchableOpacity>
          <TouchableOpacity style={[styles.menuItem, styles.logoutItem]} onPress={handleLogout}><Text style={[styles.menuText, styles.logoutText]}>تسجيل الخروج</Text></TouchableOpacity>
        </View>
        <View style={styles.footer}><Text style={styles.footerText}>عماد إكسبرس v1.0.0</Text><Text style={styles.footerSubText}>جميع الحقوق محفوظة</Text></View>
      </View>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  profileHeader: { alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 15, padding: 20, marginBottom: 20 },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#007AFF', marginBottom: 10 },
  userName: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  userEmail: { fontSize: 14, color: '#666', marginTop: 4 },
  userPhone: { fontSize: 14, color: '#666', marginTop: 2 },
  menuContainer: { backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 15, overflow: 'hidden' },
  menuItem: { paddingVertical: 15, paddingHorizontal: 20, borderBottomWidth: 1, borderBottomColor: '#eee' },
  menuText: { fontSize: 16, color: '#333' },
  logoutItem: { borderBottomWidth: 0 },
  logoutText: { color: '#f44336' },
  footer: { marginTop: 'auto', alignItems: 'center', paddingVertical: 20 },
  footerText: { fontSize: 12, color: 'rgba(255,255,255,0.7)' },
  footerSubText: { fontSize: 10, color: 'rgba(255,255,255,0.5)', marginTop: 4 },
});

export default ProfileScreen;
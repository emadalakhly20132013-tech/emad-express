import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity, Alert } from 'react-native';
import BackgroundWrapper from '../components/BackgroundWrapper';

const SettingsScreen = () => {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  const handleClearCache = () => {
    Alert.alert('مسح الكاش', 'هل أنت متأكد من مسح الكاش؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: () => Alert.alert('تم', 'تم مسح الكاش') },
    ]);
  };

  return (
    <BackgroundWrapper>
      <View style={styles.container}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإعدادات العامة</Text>
          <View style={styles.settingItem}><Text>الإشعارات</Text><Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: '#767577', true: '#007AFF' }} /></View>
          <View style={styles.settingItem}><Text>الوضع الليلي</Text><Switch value={darkMode} onValueChange={setDarkMode} trackColor={{ false: '#767577', true: '#007AFF' }} /></View>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>حول التطبيق</Text>
          <View style={styles.infoItem}><Text>الإصدار</Text><Text>1.0.0</Text></View>
          <View style={styles.infoItem}><Text>اسم التطبيق</Text><Text>عماد إكسبرس</Text></View>
        </View>
        <TouchableOpacity style={styles.clearButton} onPress={handleClearCache}><Text style={styles.clearButtonText}>مسح الكاش</Text></TouchableOpacity>
        <View style={styles.footer}><Text style={styles.footerText}>© 2025 عماد إكسبرس</Text><Text style={styles.footerSubText}>جميع الحقوق محفوظة</Text></View>
      </View>
    </BackgroundWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  section: { backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 15, padding: 15, marginBottom: 20 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, borderBottomWidth: 1, borderBottomColor: '#eee', paddingBottom: 10 },
  settingItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  infoItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10 },
  clearButton: { backgroundColor: '#f44336', borderRadius: 10, paddingVertical: 12, alignItems: 'center', marginTop: 10 },
  clearButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  footer: { marginTop: 'auto', alignItems: 'center', paddingVertical: 20 },
  footerText: { fontSize: 12, color: 'rgba(255,255,255,0.7)' },
  footerSubText: { fontSize: 10, color: 'rgba(255,255,255,0.5)', marginTop: 4 },
});

export default SettingsScreen;
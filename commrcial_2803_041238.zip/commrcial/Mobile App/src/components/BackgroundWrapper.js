import React from 'react';
import { ImageBackground, StyleSheet } from 'react-native';

const getDailyBackground = () => {
  const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  const backgrounds = {
    1: require('../assets/images/new_year.jpg'),
    14: require('../assets/images/valentine.jpg'),
    32: require('../assets/images/spring.jpg'),
    60: require('../assets/images/summer_beach.jpg'),
    180: require('../assets/images/autumn_leaves.jpg'),
    260: require('../assets/images/winter_snow.jpg'),
  };
  return backgrounds[dayOfYear] || require('../assets/images/default_bg.jpg');
};

const BackgroundWrapper = ({ children }) => {
  return (
    <ImageBackground source={getDailyBackground()} style={styles.background} resizeMode="cover">
      {children}
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: { flex: 1, width: '100%' },
});

export default BackgroundWrapper;
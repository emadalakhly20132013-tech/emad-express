import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const EmptyState = ({ message = 'لا توجد بيانات', icon = '📦' }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.icon}>{icon}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  icon: { fontSize: 48, marginBottom: 16 },
  message: { fontSize: 16, color: '#666', textAlign: 'center' },
});

export default EmptyState;
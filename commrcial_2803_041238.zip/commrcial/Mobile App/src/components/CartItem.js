import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const formatPrice = (price) => {
  return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(price);
};

const CartItem = ({ item, onRemove, onQuantityChange }) => {
  return (
    <View style={styles.container}>
      <View style={styles.info}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.price}>{formatPrice(item.price)}</Text>
      </View>
      <View style={styles.actions}>
        <View style={styles.quantityContainer}>
          <TouchableOpacity style={styles.qtyButton} onPress={() => onQuantityChange(item.quantity - 1)}>
            <Text style={styles.qtyButtonText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.quantity}>{item.quantity}</Text>
          <TouchableOpacity style={styles.qtyButton} onPress={() => onQuantityChange(item.quantity + 1)}>
            <Text style={styles.qtyButtonText}>+</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={onRemove}>
          <Text style={styles.removeText}>حذف</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 8,
  },
  info: { flex: 2 },
  name: { fontSize: 14, fontWeight: 'bold', color: '#333' },
  price: { fontSize: 12, color: '#f00', marginTop: 4 },
  actions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  quantityContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 20 },
  qtyButton: { width: 30, height: 30, justifyContent: 'center', alignItems: 'center' },
  qtyButtonText: { fontSize: 18, fontWeight: 'bold', color: '#007AFF' },
  quantity: { width: 30, textAlign: 'center', fontSize: 14, fontWeight: 'bold' },
  removeText: { color: '#f44336', fontSize: 12 },
});

export default CartItem;
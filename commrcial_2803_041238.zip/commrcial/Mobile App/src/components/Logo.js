import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const Logo = ({ size = 'large', showText = true }) => {
  const getSize = () => {
    switch (size) {
      case 'small':
        return { logo: 40, text: 16 };
      case 'large':
        return { logo: 80, text: 24 };
      default:
        return { logo: 60, text: 20 };
    }
  };

  const dimensions = getSize();

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/images/logo.png')}
        style={[styles.logo, { width: dimensions.logo, height: dimensions.logo }]}
      />
      {showText && (
        <Text style={[styles.text, { fontSize: dimensions.text }]}>
          عماد إكسبرس
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center', justifyContent: 'center' },
  logo: { borderRadius: 40, marginBottom: 8 },
  text: { fontWeight: 'bold', color: '#0A66C2' },
});

export default Logo;
import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';

const CategoryList = ({ categories, selectedCategory, onSelectCategory }) => {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.container}>
      <TouchableOpacity
        style={[styles.categoryItem, !selectedCategory && styles.selectedCategory]}
        onPress={() => onSelectCategory(null)}
      >
        <Text style={[styles.categoryText, !selectedCategory && styles.selectedText]}>الكل</Text>
      </TouchableOpacity>
      {categories.map((cat) => (
        <TouchableOpacity
          key={cat.id}
          style={[styles.categoryItem, selectedCategory === cat.id && styles.selectedCategory]}
          onPress={() => onSelectCategory(cat.id)}
        >
          <Text style={[styles.categoryText, selectedCategory === cat.id && styles.selectedText]}>
            {cat.name}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { maxHeight: 60, backgroundColor: 'rgba(255,255,255,0.9)', marginBottom: 10 },
  categoryItem: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, marginHorizontal: 4, backgroundColor: '#f0f0f0' },
  selectedCategory: { backgroundColor: '#007AFF' },
  categoryText: { fontSize: 14, color: '#333' },
  selectedText: { color: '#fff', fontWeight: 'bold' },
});

export default CategoryList;
import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

const useCartStore = create((set, get) => ({
  items: [],
  loadCart: async () => {
    const cart = await AsyncStorage.getItem('cart');
    if (cart) set({ items: JSON.parse(cart) });
  },
  addItem: async (product, quantity = 1) => {
    const current = get().items;
    const existing = current.find(i => i.id === product.id);
    let newItems;
    if (existing) {
      newItems = current.map(i => i.id === product.id ? { ...i, quantity: i.quantity + quantity } : i);
    } else {
      newItems = [...current, { ...product, quantity }];
    }
    set({ items: newItems });
    await AsyncStorage.setItem('cart', JSON.stringify(newItems));
  },
  removeItem: async (productId) => {
    const newItems = get().items.filter(i => i.id !== productId);
    set({ items: newItems });
    await AsyncStorage.setItem('cart', JSON.stringify(newItems));
  },
  updateQuantity: async (productId, quantity) => {
    if (quantity <= 0) return get().removeItem(productId);
    const newItems = get().items.map(i => i.id === productId ? { ...i, quantity } : i);
    set({ items: newItems });
    await AsyncStorage.setItem('cart', JSON.stringify(newItems));
  },
  clearCart: async () => {
    set({ items: [] });
    await AsyncStorage.removeItem('cart');
  },
  getTotal: () => get().items.reduce((sum, i) => sum + i.price * i.quantity, 0),
  getItemCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
}));

export default useCartStore;
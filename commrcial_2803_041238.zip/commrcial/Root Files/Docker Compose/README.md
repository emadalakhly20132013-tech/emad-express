# Ecommerce Platform - Microservices Architecture

## Overview
A complete ecommerce platform built with microservices architecture, including:
- User Service (Authentication & Authorization)
- Product Service (Product Management & Search)
- Inventory Service (Stock Management & Warehouses)
- Order Service (Order Processing & Cart)
- Payment Service (Payment Processing)
- Accounting Service (Double-entry Accounting)
- Vendor Service (Multi-vendor Support)
- Recommendation Service (ML-based Recommendations)
- Analytics Service (Real-time Analytics)
- Notification Service (Email, SMS, Push)
- HR Service (Employee Management)

## Architecture
![Architecture Diagram](docs/architecture.png)

## Technologies
- **Backend**: Laravel 10, Python (FastAPI)
- **Frontend**: Vue.js 3, Nuxt.js
- **Database**: MySQL, Elasticsearch, Redis
- **Message Queue**: RabbitMQ, Kafka
- **API Gateway**: Kong
- **Containerization**: Docker, Kubernetes
- **CI/CD**: GitHub Actions
- **Monitoring**: Prometheus, Grafana
- **Infrastructure**: AWS (Terraform)

## Prerequisites
- Docker & Docker Compose
- PHP 8.2+
- Node.js 18+
- Python 3.11+
- MySQL 8.0
- Redis 7.0
- Elasticsearch 8.11

## Installation

### Development Environment
```bash
# Clone repository
git clone https://github.com/your-org/ecommerce-platform.git
cd ecommerce-platform

# Copy environment file
cp .env.example .env

# Start all services
docker-compose up -d

# Run migrations
docker-compose exec user-service php artisan migrate --seed
docker-compose exec product-service php artisan migrate --seed
docker-compose exec accounting-service php artisan migrate --seed

# Access application
# API Gateway: http://localhost:8000
# Admin Panel: http://localhost:3000
# Storefront: http://localhost:3001
# Build Docker images
docker-compose -f docker-compose.prod.yml build

# Deploy to Kubernetes
kubectl apply -f shared/kubernetes/

# Apply Terraform infrastructure
cd infrastructure/terraform
terraform init
terraform plan
terraform apply
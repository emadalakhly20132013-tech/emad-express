FROM kong:latest
COPY kong.yml /etc/kong/kong.yml
ENV KONG_DATABASE=off
ENV KONG_DECLARATIVE_CONFIG=/etc/kong/kong.yml
EXPOSE 8000 8001 8443 8444
CMD ["kong", "docker-start"]